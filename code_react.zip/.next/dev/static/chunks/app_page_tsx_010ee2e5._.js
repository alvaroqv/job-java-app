(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_a0a25c34._.js",
  "static/chunks/node_modules_primereact_datatable_datatable_esm_e833540e.js",
  "static/chunks/node_modules_primereact_301e9aeb._.js",
  "static/chunks/node_modules_ba1a580d._.js"
],
    source: "dynamic"
});
