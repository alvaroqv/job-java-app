"use client"

import { useState } from "react"
import Sidebar from "@/components/sidebar"
import Dashboard from "@/components/dashboard"
import Jobs from "@/components/jobs"
import History from "@/components/history"
import Connections from "@/components/connections"
import JobWizard from "@/components/job-wizard"

export default function JobManagerApp() {
  const [activeView, setActiveView] = useState<"dashboard" | "jobs" | "history" | "connections" | "wizard">("dashboard")
  const [wizardMode, setWizardMode] = useState<"new" | "edit">("new")

  const openWizard = (mode: "new" | "edit") => {
    setWizardMode(mode)
    setActiveView("wizard")
  }

  const closeWizard = () => {
    setActiveView("jobs")
  }

  const getPageTitle = () => {
    switch (activeView) {
      case "dashboard":
        return "Visão Geral"
      case "jobs":
        return "Gerenciar Tarefas"
      case "history":
        return "Relatórios"
      case "connections":
        return "Conexões de Banco de Dados"
      case "wizard":
        return wizardMode === "edit" ? "Editar Job" : "Criar Novo Job"
      default:
        return "JobManager"
    }
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar activeView={activeView} onNavigate={setActiveView} />

      <div className="ml-[250px] flex-1 p-5">
        <div className="mb-4 flex items-center justify-between border-b pb-2">
          <h4 className="m-0 text-xl font-semibold text-gray-700">{getPageTitle()}</h4>
          <button className="rounded border border-gray-800 px-3 py-1 text-sm text-gray-800 hover:bg-gray-800 hover:text-white transition">
            <i className="pi pi-sign-out mr-2"></i> Sair
          </button>
        </div>

        {activeView === "dashboard" && <Dashboard />}
        {activeView === "jobs" && <Jobs onOpenWizard={openWizard} />}
        {activeView === "history" && <History />}
        {activeView === "connections" && <Connections />}
        {activeView === "wizard" && <JobWizard mode={wizardMode} onClose={closeWizard} />}
      </div>
    </div>
  )
}
