import { DataTable } from "primereact/datatable"
import { Column } from "primereact/column"
import { Button } from "primereact/button"

const reports = [{ id: 1, job: "Relatório Vendas", date: "30/11/2025 14:05", size: "2.4 MB" }]

export default function History() {
  const downloadBodyTemplate = () => {
    return (
      <div className="text-right">
        <Button label="CSV" icon="pi pi-download" size="small" />
      </div>
    )
  }

  return (
    <>
      <h5 className="mb-3 text-lg font-semibold">Relatórios Disponíveis</h5>
      <div className="rounded-lg bg-white shadow">
        <DataTable value={reports} stripedRows>
          <Column field="job" header="Job" />
          <Column field="date" header="Data Geração" />
          <Column field="size" header="Tamanho" />
          <Column header="Download" body={downloadBodyTemplate} />
        </DataTable>
      </div>
    </>
  )
}
