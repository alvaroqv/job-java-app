"use client"

import { useState } from "react"
import { DataTable } from "primereact/datatable"
import { Column } from "primereact/column"
import { Badge } from "primereact/badge"
import { Button } from "primereact/button"

interface Execution {
  id: number
  status: "success" | "error" | "running"
  name: string
  area: string
  startTime: string
}

const executions: Execution[] = [
  { id: 1, status: "success", name: "Relatório Vendas", area: "Comercial", startTime: "30/11 14:00" },
  { id: 2, status: "error", name: "Sync Estoque", area: "Logística", startTime: "30/11 13:55" },
  { id: 3, status: "running", name: "Fechamento", area: "Financ.", startTime: "30/11 13:50" },
]

export default function Dashboard() {
  const [filter, setFilter] = useState<string | null>(null)
  const [filteredData, setFilteredData] = useState(executions)

  const handleFilter = (status: string | null) => {
    setFilter(status)
    if (status === null || status === "all") {
      setFilteredData(executions)
    } else {
      setFilteredData(executions.filter((exec) => exec.status === status))
    }
  }

  const statusBodyTemplate = (rowData: Execution) => {
    const severityMap = {
      success: "success",
      error: "danger",
      running: "info",
    }
    const labelMap = {
      success: "Sucesso",
      error: "Erro",
      running: "Running",
    }
    return <Badge value={labelMap[rowData.status]} severity={severityMap[rowData.status] as any} />
  }

  const actionsBodyTemplate = (rowData: Execution) => {
    if (rowData.status === "error") {
      return <Button icon="pi pi-exclamation-triangle" severity="danger" outlined size="small" tooltip="Ver Erro" />
    }
    if (rowData.status === "running") {
      return <Button icon="pi pi-eye" outlined size="small" tooltip="Detalhes" />
    }
    return <Button icon="pi pi-file" outlined size="small" tooltip="Ver Log" />
  }

  const StatCard = ({ title, value, color, status }: any) => (
    <div
      onClick={() => handleFilter(status)}
      className={`cursor-pointer rounded-lg border-l-4 bg-white p-4 shadow transition hover:shadow-md hover:-translate-y-1 ${
        filter === status ? "shadow-lg -translate-y-1" : ""
      }`}
      style={{ borderColor: color }}
    >
      <h6 className="text-sm text-gray-600">{title}</h6>
      <h3 className="text-2xl font-bold">{value}</h3>
    </div>
  )

  return (
    <div>
      <div className="mb-4 grid grid-cols-1 gap-4 md:grid-cols-4">
        <StatCard title="Em Execução" value="03" color="#0d6efd" status="running" />
        <StatCard title="Sucesso (24h)" value="142" color="#198754" status="success" />
        <StatCard title="Falhas (24h)" value="02" color="#dc3545" status="error" />
        <StatCard title="Todos Jobs" value="Ver Tudo" color="#0dcaf0" status="all" />
      </div>

      <div className="rounded-lg bg-white shadow">
        <div className="border-b bg-white p-4">
          <h5 className="text-lg font-semibold">Execuções Recentes</h5>
        </div>
        <DataTable value={filteredData} stripedRows>
          <Column field="status" header="Status" body={statusBodyTemplate} />
          <Column field="name" header="Nome do Job" />
          <Column field="area" header="Área" />
          <Column field="startTime" header="Início" />
          <Column header="Ações" body={actionsBodyTemplate} className="text-right" />
        </DataTable>
      </div>
    </div>
  )
}
