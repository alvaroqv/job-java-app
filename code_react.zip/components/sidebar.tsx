"use client"

interface SidebarProps {
  activeView: string
  onNavigate: (view: "dashboard" | "jobs" | "history" | "connections") => void
}

export default function Sidebar({ activeView, onNavigate }: SidebarProps) {
  const menuItems = [
    { id: "dashboard", icon: "pi-chart-line", label: "Dashboard" },
    { id: "jobs", icon: "pi-list-check", label: "Meus Jobs" },
    { id: "history", icon: "pi-folder-open", label: "Relatórios" },
  ]

  const adminItems = [{ id: "connections", icon: "pi-database", label: "Conexões" }]

  return (
    <div className="fixed left-0 top-0 z-50 flex h-screen w-[250px] flex-col bg-gray-800 text-white">
      <div className="mb-4 border-b border-gray-700 p-5 text-center">
        <i className="pi pi-android mr-2 text-2xl"></i>
        <span className="text-xl font-bold">JobManager</span>
      </div>

      <ul className="mb-auto flex flex-col gap-1 px-3">
        {menuItems.map((item) => (
          <li key={item.id}>
            <button
              onClick={() => onNavigate(item.id as any)}
              className={`w-full rounded px-3 py-2 text-left transition ${
                activeView === item.id ? "bg-blue-600 text-white" : "text-gray-300 hover:bg-blue-600 hover:text-white"
              }`}
            >
              <i className={`pi ${item.icon} mr-2`}></i>
              {item.label}
            </button>
          </li>
        ))}

        <li className="mt-4">
          <small className="ml-2 text-xs uppercase text-gray-500">Administração</small>
        </li>

        {adminItems.map((item) => (
          <li key={item.id}>
            <button
              onClick={() => onNavigate(item.id as any)}
              className={`w-full rounded px-3 py-2 text-left transition ${
                activeView === item.id ? "bg-blue-600 text-white" : "text-gray-300 hover:bg-blue-600 hover:text-white"
              }`}
            >
              <i className={`pi ${item.icon} mr-2`}></i>
              {item.label}
            </button>
          </li>
        ))}
      </ul>

      <div className="border-t border-gray-700 bg-gray-900 p-4">
        <div className="flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-600 text-sm font-bold text-white">
            US
          </div>
          <div className="flex-1 text-sm leading-tight">
            <div className="font-semibold text-white">Usuario Silva</div>
            <div className="text-xs text-gray-400">Perfil: Executor</div>
          </div>
          <button className="rounded bg-gray-800 p-2 text-gray-400 hover:text-white">
            <i className="pi pi-cog"></i>
          </button>
        </div>
      </div>
    </div>
  )
}
