"use client"

import { useState } from "react"
import { DataTable } from "primereact/datatable"
import { Column } from "primereact/column"
import { Button } from "primereact/button"
import { Dialog } from "primereact/dialog"
import { InputText } from "primereact/inputtext"
import { Dropdown } from "primereact/dropdown"

const connections = [{ id: 1, name: "Oracle Produção", driver: "Oracle", host: "192.168.0.50", database: "DBPROD" }]

export default function Connections() {
  const [modalVisible, setModalVisible] = useState(false)
  const [modalMode, setModalMode] = useState<"new" | "edit">("new")

  const openModal = (mode: "new" | "edit") => {
    setModalMode(mode)
    setModalVisible(true)
  }

  const actionsBodyTemplate = () => {
    return (
      <div className="text-right">
        <Button icon="pi pi-pencil" outlined size="small" onClick={() => openModal("edit")} />
      </div>
    )
  }

  const drivers = [
    { label: "PostgreSQL", value: "postgresql" },
    { label: "Oracle DB", value: "oracle" },
    { label: "SQL Server", value: "sqlserver" },
    { label: "MySQL", value: "mysql" },
  ]

  return (
    <>
      <div className="mb-3 flex justify-between">
        <h5 className="text-lg font-semibold">Conexões de Banco de Dados</h5>
        <Button label="Nova Conexão" icon="pi pi-plus" onClick={() => openModal("new")} />
      </div>

      <div className="rounded-lg bg-white shadow">
        <DataTable value={connections} stripedRows>
          <Column field="name" header="Nome" />
          <Column field="driver" header="Driver" />
          <Column field="host" header="Host" />
          <Column field="database" header="Banco" />
          <Column header="Ações" body={actionsBodyTemplate} />
        </DataTable>
      </div>

      <Dialog
        header={modalMode === "new" ? "Nova Conexão" : "Editar Conexão"}
        visible={modalVisible}
        onHide={() => setModalVisible(false)}
        style={{ width: "600px" }}
        footer={
          <div>
            <Button label="Cancelar" outlined onClick={() => setModalVisible(false)} />
            <Button
              label="Salvar Conexão"
              onClick={() => {
                alert("Conexão Salva!")
                setModalVisible(false)
              }}
            />
          </div>
        }
      >
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="mb-2 block text-sm font-medium">Nome da Conexão</label>
            <InputText className="w-full" placeholder="Ex: Produção Oracle" />
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">Driver / Tipo</label>
            <Dropdown options={drivers} className="w-full" placeholder="Selecione" />
          </div>
          <div className="col-span-2">
            <label className="mb-2 block text-sm font-medium">Host (IP ou URL)</label>
            <InputText className="w-full" placeholder="192.168.x.x" />
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">Porta</label>
            <InputText type="number" className="w-full" placeholder="5432" />
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">Nome do Banco</label>
            <InputText className="w-full" placeholder="db_vendas" />
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">Usuário</label>
            <InputText className="w-full" />
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">Senha</label>
            <InputText type="password" className="w-full" />
          </div>
        </div>
      </Dialog>
    </>
  )
}
