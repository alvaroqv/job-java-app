"use client";

import { useState } from "react";
import { Button } from "primereact/button";
import { InputText } from "primereact/inputtext";
import { Dropdown } from "primereact/dropdown";
import { RadioButton } from "primereact/radiobutton";
import { InputTextarea } from "primereact/inputtextarea";
import { InputSwitch } from "primereact/inputswitch";
import { Checkbox } from "primereact/checkbox";
import { Steps } from "primereact/steps";

interface JobWizardProps {
  mode: "new" | "edit";
  onClose: () => void;
}

export default function JobWizard({ mode, onClose }: JobWizardProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [jobType, setJobType] = useState<"sql" | "python">("sql");
  const [showSqlValidation, setShowSqlValidation] = useState(false);
  const [scheduleEnabled, setScheduleEnabled] = useState(true);
  const [selectedDays, setSelectedDays] = useState([
    "seg",
    "ter",
    "qua",
    "qui",
    "sex",
  ]);
  const [params, setParams] = useState([
    { name: "data_ref", type: "Data", defaultValue: "" },
  ]);

  const steps = [
    { label: "Dados Básicos" },
    { label: "Configuração" },
    { label: "Agendamento" },
  ];

  const handleNext = () => {
    if (currentStep < 2) {
      setCurrentStep(currentStep + 1);
    } else {
      alert("Job Salvo!");
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const addParam = () => {
    setParams([...params, { name: "", type: "Texto", defaultValue: "" }]);
  };

  const removeParam = (index: number) => {
    setParams(params.filter((_, i) => i !== index));
  };

  const areas = [
    { label: "Financeiro", value: "financeiro" },
    { label: "TI", value: "ti" },
  ];

  const connections = [{ label: "Oracle Prod", value: "oracle_prod" }];

  const days = [
    { label: "Seg", value: "seg" },
    { label: "Ter", value: "ter" },
    { label: "Qua", value: "qua" },
    { label: "Qui", value: "qui" },
    { label: "Sex", value: "sex" },
    { label: "Sab", value: "sab" },
    { label: "Dom", value: "dom" },
  ];

  // API call functions
  const createJob = async (jobData: any) => {
    const response = await fetch("/api/jobs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(jobData),
    });
    if (!response.ok) {
      throw new Error("Failed to create job");
    }
    return response.json();
  };

  const updateJob = async (id: string, jobData: any) => {
    const response = await fetch(`/api/jobs/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(jobData),
    });
    if (!response.ok) {
      throw new Error("Failed to update job");
    }
    return response.json();
  };

  const handleSubmit = async () => {
    const jobData = {
      name: "Job Name", // Replace with actual form data
      type: jobType,
      params,
      schedule: {
        enabled: scheduleEnabled,
        days: selectedDays,
      },
    };

    try {
      if (mode === "new") {
        await createJob(jobData);
        alert("Job created successfully!");
      } else if (mode === "edit") {
        await updateJob("job-id", jobData); // Replace 'job-id' with the actual job ID
        alert("Job updated successfully!");
      }
      onClose();
    } catch (error) {
      console.error(error);
      alert("Failed to save job");
    }
  };

  return (
    <div className="rounded-lg bg-white shadow">
      <div className="flex items-center justify-between border-b bg-white p-4">
        <h5 className="m-0 text-lg font-semibold">
          {mode === "edit" ? "Editar Job" : "Criar Novo Job"}
        </h5>
        <Button label="Cancelar" outlined size="small" onClick={onClose} />
      </div>

      <div className="p-6">
        <div className="mb-6">
          <Steps model={steps} activeIndex={currentStep} />
        </div>

        {/* Step 1: Dados Básicos */}
        {currentStep === 0 && (
          <div className="space-y-4">
            <h6 className="mb-4 text-center font-semibold">Dados Básicos</h6>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-2 block text-sm font-medium">
                  Nome do Job
                </label>
                <InputText className="w-full" />
              </div>
              <div>
                <label className="mb-2 block text-sm font-medium">Área</label>
                <Dropdown
                  options={areas}
                  className="w-full"
                  placeholder="Selecione"
                  value={jobType}
                  onChange={(e) => setJobType(e.value)}
                />
              </div>
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium">
                Tipo de Job
              </label>
              <div className="flex gap-4">
                <div className="flex items-center">
                  <RadioButton
                    inputId="typeSQL"
                    value="sql"
                    checked={jobType === "sql"}
                    onChange={(e) => setJobType(e.value)}
                  />
                  <label htmlFor="typeSQL" className="ml-2">
                    Query SQL
                  </label>
                </div>
                <div className="flex items-center">
                  <RadioButton
                    inputId="typePython"
                    value="python"
                    checked={jobType === "python"}
                    onChange={(e) => setJobType(e.value)}
                  />
                  <label htmlFor="typePython" className="ml-2">
                    Script Python
                  </label>
                </div>
              </div>
            </div>

            <div className="mt-4">
              <label className="mb-2 block text-sm font-semibold">
                Parâmetros de Entrada
              </label>
              <div className="rounded border bg-gray-50 p-3">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="pb-2 text-left">Nome Param</th>
                      <th className="pb-2 text-left">Tipo</th>
                      <th className="pb-2 text-left">Valor Padrão</th>
                      <th className="pb-2 text-left">Ação</th>
                    </tr>
                  </thead>
                  <tbody>
                    {params.map((param, index) => (
                      <tr key={index}>
                        <td className="py-2">
                          <InputText
                            value={param.name}
                            className="w-full"
                            onChange={(e) => {
                              const updatedParams = [...params];
                              updatedParams[index].name = e.target.value;
                              setParams(updatedParams);
                            }}
                            size="small"
                          />
                        </td>
                        <td className="py-2 pl-2">
                          <Dropdown
                            value={param.type}
                            options={[
                              { label: "Data", value: "Data" },
                              { label: "Texto", value: "Texto" },
                            ]}
                            onChange={(e) => {
                              const updatedParams = [...params];
                              updatedParams[index].type = e.value;
                              setParams(updatedParams);
                            }}
                            className="w-full"
                          />
                        </td>
                        <td className="py-2 pl-2">
                          <InputText
                            value={param.defaultValue}
                            className="w-full"
                            onChange={(e) => {
                              const updatedParams = [...params];
                              updatedParams[index].defaultValue =
                                e.target.value;
                              setParams(updatedParams);
                            }}
                            size="small"
                          />
                        </td>
                        <td className="py-2 pl-2">
                          <Button
                            icon="pi pi-times"
                            severity="danger"
                            outlined
                            size="small"
                            onClick={() => removeParam(index)}
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <Button
                  label="+ Adicionar Parâmetro"
                  link
                  size="small"
                  className="mt-2"
                  onClick={addParam}
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Configuração */}
        {currentStep === 1 && (
          <div>
            {jobType === "sql" && (
              <div className="space-y-4">
                <h6 className="mb-4 text-center font-semibold">
                  Configurar Query SQL
                </h6>

                <div>
                  <label className="mb-2 block text-sm font-medium">
                    Conexão
                  </label>
                  <Dropdown
                    options={connections}
                    className="w-1/2"
                    placeholder="Selecione"
                  />
                </div>

                <div>
                  <label className="mb-2 block text-sm font-medium">
                    Query
                  </label>
                  <InputTextarea
                    rows={5}
                    className="w-full font-mono"
                    style={{ backgroundColor: "#1e1e1e", color: "#d4d4d4" }}
                    defaultValue="SELECT * FROM tabela WHERE dt = :data_ref"
                  />
                </div>

                <Button
                  label="Validar & Mapear Colunas"
                  icon="pi pi-sync"
                  outlined
                  size="small"
                  onClick={() => setShowSqlValidation(true)}
                />

                {showSqlValidation && (
                  <div className="rounded border bg-gray-50 p-4">
                    <label className="mb-2 block font-semibold text-green-600">
                      <i className="pi pi-check-circle mr-2"></i>
                      Colunas Detectadas:
                    </label>
                    <table className="w-full border bg-white text-sm">
                      <thead>
                        <tr className="border-b bg-gray-100">
                          <th className="p-2 text-left">Coluna SQL</th>
                          <th className="p-2 text-left">Alias Relatório</th>
                          <th className="p-2 text-left">Formato</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b">
                          <td className="p-2">data_venda</td>
                          <td className="p-2">
                            <InputText
                              defaultValue="Data Venda"
                              size="small"
                              className="w-full"
                            />
                          </td>
                          <td className="p-2">
                            <Dropdown
                              options={[{ label: "DD/MM/AAAA", value: "date" }]}
                              defaultValue="date"
                              className="w-full"
                            />
                          </td>
                        </tr>
                        <tr>
                          <td className="p-2">valor</td>
                          <td className="p-2">
                            <InputText
                              defaultValue="Valor"
                              size="small"
                              className="w-full"
                            />
                          </td>
                          <td className="p-2">
                            <Dropdown
                              options={[
                                { label: "Moeda R$", value: "currency" },
                              ]}
                              defaultValue="currency"
                              className="w-full"
                            />
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {jobType === "python" && (
              <div>
                <h6 className="mb-4 text-center font-semibold">
                  Configurar Script Python
                </h6>
                <Dropdown
                  options={[{ label: "etl_mensal.py", value: "etl_mensal" }]}
                  className="w-full"
                  placeholder="Selecione o script"
                />
              </div>
            )}
          </div>
        )}

        {/* Step 3: Agendamento */}
        {currentStep === 2 && (
          <div className="space-y-4">
            <h6 className="mb-4 text-center font-semibold">
              Agendamento & Notificações
            </h6>

            <div className="flex items-center gap-3 rounded border bg-gray-50 p-3">
              <InputSwitch
                checked={scheduleEnabled}
                onChange={(e) => setScheduleEnabled(e.value)}
              />
              <label className="font-semibold">
                Execução Automática (Agendada)
              </label>
            </div>

            {scheduleEnabled && (
              <div className="space-y-4">
                <div>
                  <label className="mb-2 block text-sm font-medium">
                    Dias da Execução:
                  </label>
                  <div className="flex gap-2">
                    {days.map((day) => (
                      <div key={day.value} className="flex items-center">
                        <Checkbox
                          inputId={day.value}
                          value={day.value}
                          checked={selectedDays.includes(day.value)}
                          onChange={(e) => {
                            if (e.checked) {
                              setSelectedDays([...selectedDays, day.value]);
                            } else {
                              setSelectedDays(
                                selectedDays.filter((d) => d !== day.value)
                              );
                            }
                          }}
                        />
                        <label htmlFor={day.value} className="ml-1 text-sm">
                          {day.label}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="mb-2 block text-sm font-medium">
                      Horário de Início:
                    </label>
                    <InputText
                      type="time"
                      defaultValue="08:00"
                      className="w-full"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="mb-2 block text-sm font-medium">
                      Intervalo de Repetição:
                    </label>
                    <Dropdown
                      options={[
                        {
                          label: "Executar uma vez por dia (No horário acima)",
                          value: "once",
                        },
                        { label: "Repetir a cada 1 hora", value: "1h" },
                        { label: "Repetir a cada 6 horas", value: "6h" },
                        { label: "Repetir a cada 12 horas", value: "12h" },
                      ]}
                      className="w-full"
                      defaultValue="once"
                    />
                  </div>
                </div>
              </div>
            )}

            <hr className="my-4" />

            <div>
              <label className="mb-2 block text-sm font-medium">
                Notificar por E-mail (Separar por vírgula):
              </label>
              <InputText className="w-full" placeholder="gestor@empresa.com" />
            </div>
          </div>
        )}

        <div className="mt-6 flex justify-between border-t pt-4">
          <Button
            label="Voltar"
            severity="secondary"
            disabled={currentStep === 0}
            onClick={handlePrev}
          />
          <Button
            label={currentStep === 2 ? "Salvar" : "Próximo"}
            onClick={currentStep === 2 ? handleSubmit : handleNext}
          />
        </div>
      </div>
    </div>
  );
}
