"use client"

import { useState } from "react"
import { DataTable } from "primereact/datatable"
import { Column } from "primereact/column"
import { Button } from "primereact/button"
import { Dialog } from "primereact/dialog"
import { Badge } from "primereact/badge"

interface Job {
  id: number
  name: string
  type: "SQL" | "Python"
  cron: string
}

const jobs: Job[] = [{ id: 1, name: "Relatório Vendas", type: "SQL", cron: "0 8 * * 1" }]

interface JobsProps {
  onOpenWizard: (mode: "new" | "edit") => void
}

export default function Jobs({ onOpenWizard }: JobsProps) {
  const [deleteVisible, setDeleteVisible] = useState(false)
  const [runVisible, setRunVisible] = useState(false)

  const typeBodyTemplate = (rowData: Job) => {
    return <Badge value={rowData.type} severity="info" />
  }

  const actionsBodyTemplate = () => {
    return (
      <div className="flex justify-end gap-2">
        <Button
          icon="pi pi-play"
          severity="success"
          size="small"
          tooltip="Executar Agora"
          onClick={() => setRunVisible(true)}
        />
        <Button icon="pi pi-pencil" outlined size="small" tooltip="Editar Job" onClick={() => onOpenWizard("edit")} />
        <Button
          icon="pi pi-trash"
          severity="danger"
          outlined
          size="small"
          tooltip="Excluir Job"
          onClick={() => setDeleteVisible(true)}
        />
      </div>
    )
  }

  return (
    <>
      <div className="mb-3 flex justify-between">
        <h5 className="text-lg font-semibold">Gerenciar Tarefas</h5>
        <Button label="Novo Job" icon="pi pi-plus" onClick={() => onOpenWizard("new")} />
      </div>

      <div className="rounded-lg bg-white shadow">
        <DataTable value={jobs} stripedRows>
          <Column field="name" header="Nome" />
          <Column field="type" header="Tipo" body={typeBodyTemplate} />
          <Column field="cron" header="CRON" />
          <Column header="Ações" body={actionsBodyTemplate} className="text-right" />
        </DataTable>
      </div>

      <Dialog
        header="Confirmar"
        visible={deleteVisible}
        onHide={() => setDeleteVisible(false)}
        style={{ width: "400px" }}
        footer={<Button label="Excluir" severity="danger" onClick={() => setDeleteVisible(false)} />}
      >
        <p>Excluir este Job?</p>
      </Dialog>

      <Dialog
        header="Executar"
        visible={runVisible}
        onHide={() => setRunVisible(false)}
        style={{ width: "400px" }}
        footer={<Button label="Executar" severity="success" onClick={() => setRunVisible(false)} />}
      >
        <p>Parametros...</p>
      </Dialog>
    </>
  )
}
