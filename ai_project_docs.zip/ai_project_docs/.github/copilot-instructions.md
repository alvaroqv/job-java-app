# Copilot / AI Agent Instructions — ai_project_docs

Purpose
- Help AI agents be immediately productive in this repository by capturing structural rules,
  build/test/debug workflows, and project-specific conventions discoverable from the code and docs.

Quick summary
- Java 21, Spring Boot (SSR) service. SQL-first data access with external DDL management. SAML2 ADFS
  for auth and server-side RBAC. See [docs/architecture.md](docs/architecture.md) for the topology.

High-level architecture (what to know)
- Major layers: Controllers (thin), Services (business logic), Repositories (SQL only).
- Data flow: Controller -> Service -> Repository (repository executes parameterized SQL).
- Reasoning: SQL-first and external DDL means schema changes are managed outside app code.

Important project rules (do not change)
- Controllers must remain thin; move business rules into `service` classes.
- Repositories contain SQL only. Use parameterized SQL; never string-concatenate queries.
- CSRF remains enabled; do not disable security protections.
- RBAC is enforced server-side — do not shift authorization to client.
- Do not add Flyway/Liquibase or other DB migration frameworks (schema managed externally).

Developer workflows (concrete commands)
- Build & run tests: `mvn -DskipTests=false clean verify`
- Package (skip tests when needed): `mvn -DskipTests package`
- Run locally: `mvn spring-boot:run` or `java -jar target/*.jar` after a package.
- Run tests (single test): `mvn -Dtest=<FQCN>#<method> test`
- Remote debug with Maven: `mvn spring-boot:run -Dspring-boot.run.jvmArguments="-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005"`

Testing and CI
- JUnit 5 is used. Keep tests focused on behavior (service-layer) rather than controller wiring.
- Use `mvn -DskipTests=false verify` locally to replicate CI gating.

Logging and observability
- Structured Splunk logging is used; include `correlationId` and `userId` in logs when adding instrumentation.

Integration points and external systems
- Authentication: Microsoft ADFS (SAML2) — configuration and secrets live outside source control.
- Database: SQL-first; DDL and schema migrations are handled externally. Look for SQL artifacts in the repo
  and the runbook for deployment steps. See [docs/runbook.md](docs/runbook.md) for run/deploy notes.

Conventions & patterns (examples)
- Thin controller example: find controllers under `src/main/java/.../controller` and delegate to
  `*Service` classes for logic.
- SQL repositories: SQL is kept in repository classes or external `.sql` files — preserve parameterization.
- Tests: prefer service-level unit tests over end-to-end tests for fast feedback loops.

AI agent behavior guidelines
- Preserve security and architectural constraints: do not modify CSRF, RBAC, or replace SQL-first
  schema management with migrations.
- When refactoring: move logic from controllers into existing `service` classes; keep controller signatures stable.
- Avoid adding new top-level frameworks or changing project structure (no SPA frameworks, no Liquibase/Flyway).
- Prefer minimal, targeted changes and include tests that validate behavior you changed.

References
- Architecture overview: [docs/architecture.md](docs/architecture.md)
- Runbook and environment notes: [docs/runbook.md](docs/runbook.md)
- Changelog for historical decisions: [CHANGELOG.md](CHANGELOG.md)

If anything here is unclear or you want more detail (specific file examples, package names,
or CI details), tell me which area to expand and I will iterate.
# Copilot Global Instructions

This project uses:

-   Java 21
-   Spring Boot + Spring MVC (SSR)
-   SQL-first data access
-   External SQL DDL schema management
-   Microsoft ADFS (SAML2)
-   Role-Based Access Control (RBAC)
-   Maven
-   JUnit 5
-   Structured Splunk logging

## Core Rules

-   Controllers must remain thin.
-   Business logic belongs in services.
-   Repositories contain SQL only.
-   Always use parameterized SQL.
-   Never disable security protections.
-   CSRF must remain enabled.
-   Enforce RBAC server-side.
-   Logs must include correlationId and userId.
-   Do not introduce SPA frameworks.
-   Do not introduce Flyway/Liquibase.

## Testing

-   JUnit 5 only.
-   80--90% coverage acceptable.
-   100% ideal for critical logic.
-   No artificial tests to inflate coverage.
