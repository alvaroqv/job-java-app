---
applyTo: "**/*.java"
description: "Guidelines for building Spring Boot base applications"
---

# Java Development Instructions

## Java Engineering Standards (Java 21)

Copilot must follow these Java best practices and proactively prevent bugs and code smells.
Address code smells early (during development) instead of accumulating technical debt.
Prefer readability, maintainability, and performance when refactoring.
Always leverage IDE/editor warnings and suggestions to catch common patterns early.

### Language Features & Modern Java

- **Records**: For data carriers (DTOs, immutable request/response models, small value objects), prefer **Java Records** over mutable POJOs.
- **Pattern Matching**:
  - Use pattern matching for `instanceof` to avoid manual casts.
  - Use `switch` expressions when it reduces branching and improves clarity.
- **Type Inference (`var`)**:
  - Use `var` only when the type is obvious from the RHS (e.g., `var users = repository.findAll()`).
  - Do NOT use `var` when it harms readability (e.g., `var x = foo()` with unclear type).
- **Immutability by default**:
  - Prefer immutable objects; use `final` for fields/classes/method parameters where reasonable.
  - Use `List.of()` / `Map.of()` for fixed data.
  - Use `stream().toList()` for immutable lists.
  - Avoid exposing internal mutable collections; return unmodifiable views or immutable snapshots.

### Null Handling & Contracts

- Avoid returning or accepting `null`.
- Use `Optional<T>` for possibly-absent values in APIs (especially service boundaries).
- Validate non-null inputs with `Objects.requireNonNull(...)`.
- Use `Objects.equals(a,b)` for safe equality checks.
- Favor explicit preconditions and meaningful exceptions over null propagation.

### Streams & Lambdas

- Use Streams for collection processing when it improves clarity.
- Prefer method references when readable (e.g., `stream.map(Foo::toBar)`).
- Avoid overusing streams for complex logic; do not create unreadable pipelines.
- Do not use streams for side effects (e.g., avoid `peek()` except for debugging).
- Keep lambda bodies short; extract to named methods when they grow.

### Clean Code & Separation of Responsibilities

- Keep controllers thin; no business logic in web layer.
- Keep services cohesive: one responsibility, clear business intent.
- Keep repositories focused on data access only (SQL + mapping), no business rules.
- Prefer small, focused methods and classes.
- Avoid deep nesting; prefer guard clauses and extracted helper methods.
- Minimize duplication; extract shared logic carefully (avoid “utility dumping ground”).

### Naming Conventions (Google Java Style)

- `UpperCamelCase` for classes/interfaces.
- `lowerCamelCase` for methods/variables.
- `UPPER_SNAKE_CASE` for constants.
- `lowercase` for package names.
- Classes are nouns (e.g., `UserService`), methods are verbs (e.g., `getUserById`).
- Avoid abbreviations, Hungarian notation, and ambiguous names.
- Prefer intention-revealing names over short names.

### Common Bug Patterns (Prevent Proactively)

- **Resource management**:
  - Always close resources (files, sockets, streams).
  - Prefer **try-with-resources**.
- **Equality checks**:
  - Use `.equals()` or `Objects.equals(...)` for non-primitives.
  - Use `==` only for primitives or identity checks where intentional.
- **Redundant casts**:
  - Remove unnecessary casts; fix generics typing instead.
- **Reachable / constant conditions**:
  - Avoid conditions that are always true/false; treat them as bugs or dead code.

> If Sonar/SonarLint/SpotBugs/PMD flags an issue, prefer the tool’s location and remediation guidance.
> If Sonar rule keys are shown (e.g., S2095 for resource leaks), fix using the tool’s exact guidance.

### Common Code Smells (Avoid / Refactor Early)

- **Long parameter lists**:
  - Keep parameter lists short. If many params exist, group into a value object/record or use Builder.
- **Large methods**:
  - Keep methods small; extract helper methods for readability and testability.
- **High cognitive complexity**:
  - Reduce nesting/branching; extract methods, use polymorphism, or Strategy pattern where appropriate.
- **Duplicated literals**:
  - Extract repeated strings/numbers into named constants or enums.
- **Dead code**:
  - Remove unused variables/assignments/imports; they hide bugs and confuse readers.
- **Magic numbers**:
  - Replace numeric literals with named constants that explain intent (e.g., `MAX_RETRIES`).

### “Do Not Do” List (Java)

- Do not introduce unnecessary abstraction layers.
- Do not create “fake” unit tests purely to increase coverage.
- Do not suppress warnings without justification.
- Do not ignore IDE warnings about nullability, resources, or unreachable code.
- Do not compromise readability to force modern features (use them only when they improve clarity).
