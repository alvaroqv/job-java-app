# Changelog

All notable changes to this project will be documented in this file.

The format is based on **Keep a Changelog**.
This project adheres to **Semantic Versioning (SemVer)**.

---

# [Unreleased]

## Added

-

## Changed

-

## Fixed

-

## Security

-

## Performance

-

## Observability

-

## Architecture

-

## Database

- ***

# Versioning Policy

This project follows **Semantic Versioning**:

MAJOR.MINOR.PATCH

- MAJOR → incompatible API/architecture changes
- MINOR → backward-compatible feature additions
- PATCH → backward-compatible bug fixes

Security-only fixes increment PATCH unless behavior changes significantly.

---

# Change Categories

## Added

New features, endpoints, services, roles, dashboards, or architectural components.

## Changed

Modifications to behavior, business rules, flows, configurations, or dependencies.

## Fixed

Bug fixes affecting logic, security, validation, or performance.

## Security

Authentication (SAML2), authorization (RBAC), CSRF, validation, and vulnerability-related changes.

## Performance

Query optimization, indexing guidance, caching, or latency improvements.

## Observability

Changes to structured logging, Splunk fields, correlationId, audit events, or monitoring.

## Architecture

Layer changes, dependency shifts, design pattern updates, refactors impacting structure.

## Database

Schema modifications (managed externally via SQL DDL), query logic changes, performance adjustments.

---

# Example Entries

---

# [1.2.0] - 2024-03-15

## Added

- New backoffice user management screen.
- ROLE_MANAGER support with restricted edit permissions.
- Audit log event: USER_UPDATED.

## Changed

- Refactored UserService to separate validation logic.
- Improved pagination strategy for large datasets.

## Security

- Enforced role validation at service layer.
- Hardened SAML role mapping to normalize ROLE\_ prefix.

## Observability

- Added correlationId to audit logs.
- Included userId and roles fields in mutation events.

## Database

- Added new column `last_modified_at` (DDL managed externally).

---

# [1.1.1] - 2024-02-10

## Fixed

- Resolved NullPointerException in role mapping.
- Fixed missing CSRF token in update form.

## Security

- Prevented unauthorized access to dashboard metrics endpoint.

---

# Documentation Requirements

Every version entry must:

- Be dated (YYYY-MM-DD).
- Clearly categorize changes.
- Reference related ticket or PR when available.
- Explain security and RBAC impacts explicitly.
- Document database changes even if DDL is managed externally.

---

# AI Governance Note

All changes impacting:

- Authentication
- Authorization
- Logging structure
- Architecture
- SQL patterns
- Testing standards

Must be reflected both in:

- This CHANGELOG.md
- Relevant documentation under /docs
- Prompt assumptions if applicable

---

# Release Checklist

Before tagging a version:

- All tests passing (JUnit 5).
- Coverage within acceptable range (80–90% or justified).
- RBAC enforcement validated.
- Structured logging present.
- No SQL string concatenation.
- No security rules disabled.
- Documentation updated.
- CHANGELOG updated.
