# System Architecture — Backoffice & Dashboard

## 1. Overview

This system is an enterprise-grade backoffice and dashboard platform designed for:

- Secure role-based access
- Data-heavy administrative workflows
- Audit-sensitive operations
- Maintainable long-term evolution

The architecture prioritizes:

- Clarity
- Layered separation of responsibilities
- Observability
- Security
- Maintainability
- AI-assisted development discipline

---

## 2. Technology Stack

### Backend

- Java 21
- Spring Boot
- Spring MVC (Server-Side Rendering)
- Thymeleaf

### Security

- Microsoft ADFS (SAML 2.0)
- Spring Security
- Role-Based Access Control (RBAC)

### Data Access

- SQL-first approach
- NamedParameterJdbcTemplate (or equivalent)
- External SQL DDL tool manages schema

### Build

- Maven

### Testing

- JUnit 5
- MockMvc
- Optional Testcontainers

### Observability

- Structured JSON logging
- Splunk ingestion
- CorrelationId-based tracing

---

## 3. Architectural Principles

### 3.1 Layered Architecture

The system follows a strict layered model:

HTTP Request  
→ Controller (Web Layer)  
→ Service (Application Layer)  
→ Repository (Infrastructure Layer)  
→ Database

Each layer has a single responsibility.

---

### 3.2 Separation of Responsibilities

| Layer          | Responsibility                                          |
| -------------- | ------------------------------------------------------- |
| Web            | Request mapping, validation binding, response rendering |
| Application    | Business logic and use cases                            |
| Domain         | Business rules, models, invariants                      |
| Infrastructure | SQL, security, logging, external integrations           |

Controllers must remain thin.  
Business logic must not leak into repositories.  
Repositories must not contain business rules.

---

### 3.3 Server-Side Rendering Model

- Spring MVC + Thymeleaf
- Minimal JavaScript
- No SPA frameworks
- Desktop-first UX
- Validation errors rendered server-side

---

## 4. Security Architecture

### 4.1 Authentication

- SSO via Microsoft ADFS
- SAML 2.0 login
- Service Provider configuration in Spring Security
- Metadata managed per environment

---

### 4.2 Authorization

Role-Based Access Control (RBAC)

- Roles derived from SAML claims
- Mapped to `GrantedAuthority`
- Enforced:
  - At endpoint level
  - At service layer for critical business rules
- Never rely solely on UI hiding

---

### 4.3 Mandatory Protections

- CSRF enabled
- Secure session management
- Session fixation protection
- No secret/token logging
- Strict server-side validation

---

## 5. Data Architecture

### 5.1 SQL-First Policy

- Explicit SQL queries
- Parameterized queries only
- No string concatenation
- Clear transaction boundaries

---

### 5.2 Schema Management

- Database schema managed externally
- DDL scripts stored under `/ddl`
- Application does not manage migrations
- Schema changes documented in CHANGELOG and docs

---

### 5.3 Query Strategy

- Pagination required for large datasets
- Sorting via whitelisted columns
- Index-aware design
- Avoid N+1 query patterns

---

## 6. Logging & Observability Architecture

### 6.1 Structured Logging

All logs must include:

- timestamp
- level
- service
- env
- version
- requestId / correlationId
- userId
- roles
- httpMethod
- path
- status
- durationMs
- errorId (for exceptions)

---

### 6.2 Audit Logging

For every mutation (Create/Update/Delete):

- eventName
- entity
- entityId
- action
- outcome
- userId
- roles

Audit logs must be Splunk-searchable.

---

### 6.3 Error Handling Strategy

- Centralized ControllerAdvice
- User-safe error messages
- Unique errorId returned
- Full stacktrace logged only

---

## 7. Testing Architecture

### 7.1 Testing Layers

- Unit tests (business logic)
- Controller tests (MockMvc)
- Security boundary tests
- Repository integration tests
- CSRF validation tests

---

### 7.2 Coverage Policy

- 80–90% acceptable
- 100% ideal for critical logic
- No artificial tests for coverage inflation

---

## 8. Performance & Scalability Considerations

- Avoid deep object graphs
- Avoid heavy synchronous blocking
- Optimize SQL with indexes
- Monitor slow queries via logs
- Avoid excessive logging in hot paths

---

## 9. Request Flow Example

Authenticated Request:

Browser  
→ ADFS Login  
→ SAML Assertion  
→ Spring Security  
→ Controller  
→ Service  
→ Repository (SQL)  
→ Database  
→ Response  
→ Structured Log Event

---

## 10. Error Flow Example

Exception thrown  
→ ControllerAdvice  
→ errorId generated  
→ Structured error log created  
→ User-safe message returned

---

## 11. AI-Driven Development Model

This project uses an AI-assisted operating model with defined roles:

- Product Owner
- UX Specialist
- Dev Leader
- Developer
- Tester
- QA
- Troubleshooting Specialist
- Documentation Specialist

Architecture decisions must remain consistent with:

- copilot-instructions.md
- Prompt definitions
- CHANGELOG
- Runbook

AI suggestions must not override architectural rules.

---

## 12. Non-Functional Requirements

### Security

Strong SSO + RBAC enforcement.

### Observability

Full traceability via structured logs.

### Maintainability

Layer separation and clean code standards.

### Auditability

All relevant changes logged and documented.

### Stability

Backward-compatible changes unless MAJOR version.

---

## 13. Evolution Guidelines

When modifying the system:

- Evaluate impact across layers.
- Evaluate RBAC impact.
- Evaluate logging impact.
- Update documentation.
- Update CHANGELOG.
- Keep AI prompts consistent.

---

## 14. Architectural Constraints (Hard Rules)

The system must not:

- Introduce SPA frameworks.
- Use in-app schema migration tools.
- Disable security protections.
- Use non-parameterized SQL.
- Log secrets.
- Break layered separation.

---

## 15. Future Evolution Areas (Optional)

- API exposure layer (if needed)
- Caching strategy
- Read-model optimization
- Advanced metrics integration
- Multi-tenant support

---

## 16. Versioning Policy

This project adheres to **Semantic Versioning (SemVer)**.

This document represents the authoritative architectural reference for the system. All development must adhere to these principles and guidelines to ensure a secure, maintainable, and scalable platform.
