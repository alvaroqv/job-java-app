# Runbook

## Run Locally

./mvnw clean install ./mvnw spring-boot:run

## Common Issues

403 after login: - Check role mapping - Verify SAML claim

CSRF error: - Ensure token present in form

Slow query: - Check indexes - Verify pagination

## Production Checklist

-   Tests passing
-   Coverage acceptable
-   RBAC validated
-   Logs structured
