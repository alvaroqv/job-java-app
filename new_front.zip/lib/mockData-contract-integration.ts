import type { ContractIntegration, ContractIntegrationStats } from "@/types/contract-integration"

export const mockContractIntegrationStats: ContractIntegrationStats = {
  sent: 150,
  imported: 142,
  notImported: 8,
}

export const mockContractIntegrations: ContractIntegration[] = [
  {
    id: "1",
    contractNumber: "CT-998877",
    boletaNumber: "BOL-1002",
    clientCnpj: "12.345.678/0001-90",
    contractDate: "2025-01-10",
    status: "imported",
    processingLog: "Integrado com sucesso no ERP.",
  },
  {
    id: "2",
    contractNumber: "CT-998878",
    boletaNumber: "BOL-1003",
    clientCnpj: "98.765.432/0001-00",
    contractDate: "2025-01-10",
    status: "not_imported",
    processingLog: "Erro: Cliente com CPF inválido ou inexistente na base.",
    errorDetails:
      "Error Code: 404_CLIENT_NOT_FOUND\nContrato: CT-998878\nCNPJ: 98.765.432/0001-00\n\nDetalhes: O cliente não foi encontrado na base de dados. Verifique se o CNPJ está correto e se o cliente foi previamente cadastrado no sistema.",
  },
  {
    id: "3",
    contractNumber: "CT-998879",
    boletaNumber: "BOL-1004",
    clientCnpj: "33.444.555/0001-22",
    contractDate: "2025-01-11",
    status: "imported",
    processingLog: "Integrado com sucesso.",
  },
  {
    id: "4",
    contractNumber: "CT-998880",
    boletaNumber: "BOL-1005",
    clientCnpj: "44.555.666/0001-33",
    contractDate: "2025-01-11",
    status: "imported",
    processingLog: "Integrado com sucesso no ERP.",
  },
  {
    id: "5",
    contractNumber: "CT-998881",
    boletaNumber: "BOL-1006",
    clientCnpj: "55.666.777/0001-44",
    contractDate: "2025-01-12",
    status: "not_imported",
    processingLog: "Erro: Dados incompletos no contrato.",
    errorDetails:
      "Error Code: 400_INCOMPLETE_DATA\nContrato: CT-998881\nCNPJ: 55.666.777/0001-44\n\nDetalhes: Faltam informações obrigatórias no contrato. Verifique os campos obrigatórios.",
  },
]
