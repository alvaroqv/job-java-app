import type {
  Customer,
  CustomerKPIs,
  CustomerListResponse,
} from "@/types/customer";

export const mockCustomerKPIs: CustomerKPIs = {
  newRegistrations: {
    count: 24,
    percentageChange: 12,
  },
  updates: {
    count: 156,
  },
  deactivations: {
    count: 5,
  },
  reactivations: {
    count: 12,
  },
};

export const mockCustomers: Customer[] = [
  {
    id: "1",
    name: "Tech Solutions Ltda",
    email: "contato@techsol.com",
    eci: "ECI-9021",
    cnpjCpf: "12.345.678/0001-90",
    createdAt: "2025-01-10",
    updatedAt: "2025-02-08",
    status: "Ativo",
    situation: "Regular",
    avatar: "T",
  },
  {
    id: "2",
    name: "Mercado Silva",
    email: "financeiro@msilva.com",
    eci: "ECI-8840",
    cnpjCpf: "98.765.432/0001-10",
    createdAt: "2024-11-15",
    updatedAt: "2024-11-30",
    status: "Inativo",
    situation: "Bloqueado",
    avatar: "M",
  },
  {
    id: "3",
    name: "João da Silva (MEI)",
    email: "joao@email.com",
    eci: "ECI-1029",
    cnpjCpf: "111.222.333-44",
    createdAt: "2025-02-01",
    updatedAt: "2025-02-01",
    status: "Ativo",
    situation: "Em Análise",
    avatar: "J",
  },
  {
    id: "4",
    name: "Indústria XYZ S.A.",
    email: "comercial@xyz.com.br",
    eci: "ECI-7755",
    cnpjCpf: "22.333.444/0001-55",
    createdAt: "2024-12-20",
    updatedAt: "2025-01-15",
    status: "Ativo",
    situation: "Regular",
    avatar: "I",
  },
  {
    id: "5",
    name: "Maria Comércio LTDA",
    email: "maria@comercio.com",
    eci: "ECI-6622",
    cnpjCpf: "33.444.555/0001-66",
    createdAt: "2025-01-05",
    updatedAt: "2025-01-28",
    status: "Ativo",
    situation: "Regular",
    avatar: "M",
  },
];

export const mockCustomerListResponse: CustomerListResponse = {
  customers: mockCustomers,
  kpis: mockCustomerKPIs,
  totalRecords: mockCustomers.length,
};

// Simulate API delay
export const delay = (ms: number) =>
  new Promise((resolve) => setTimeout(resolve, ms));
