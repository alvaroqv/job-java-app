import type { PartyClient } from "@/types/party-client"

// Mock data for PartyClient API responses
export const mockPartyClients: Record<string, PartyClient> = {
  "90210": {
    eci: "90210-BR",
    name: "Mega Distribuidora Party S.A.",
    document: "45.123.987/0001-55",
    status: "ATIVO",
    situation: "REGULAR",
    situationDetail: "Auditado",
  },
  "12345": {
    eci: "12345-BR",
    name: "Tech Solutions Ltda",
    document: "12.345.678/0001-90",
    status: "ATIVO",
    situation: "REGULAR",
    situationDetail: "Verificado",
  },
  "67890": {
    eci: "67890-BR",
    name: "Comercial Silva & Cia",
    document: "98.765.432/0001-11",
    status: "INATIVO",
    situation: "IRREGULAR",
    situationDetail: "Pendências Fiscais",
  },
}

export const getPartyClientByECI = (eci: string): PartyClient | undefined => {
  // Extract just the number part before any dash or suffix
  const eciNumber = eci.split("-")[0].trim()
  return mockPartyClients[eciNumber]
}
