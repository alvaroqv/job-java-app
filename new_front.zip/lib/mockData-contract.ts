import type { Contract, ContractStats } from "@/types/contract"

export const mockContractStats: ContractStats = {
  newContracts: 12,
  pendingSignature: 8,
  signed: 145,
}

export const mockContracts: Contract[] = [
  {
    id: "1",
    clientName: "Tech Solutions S.A.",
    contractCode: "CT-2025/001",
    eci: "90210-BR",
    document: "12.345.678/0001-90",
    status: "Assinado",
    contractDate: "2025-01-10",
    signatureDate: "2025-01-15",
    callbackDate: "2025-01-16",
    pdfUrl: "/contracts/ct-2025-001.pdf",
  },
  {
    id: "2",
    clientName: "Grupo Alpha Retail",
    contractCode: "CT-2025/008",
    eci: "55021-RJ",
    document: "33.444.555/0001-22",
    status: "Assinado",
    contractDate: "2025-01-12",
    signatureDate: "2025-01-20",
    pdfUrl: "/contracts/ct-2025-008.pdf",
  },
  {
    id: "3",
    clientName: "Mercado Silva Ltda",
    contractCode: "CT-2025/015",
    eci: "88848-SP",
    document: "98.765.432/0001-10",
    status: "Pendente",
    contractDate: "2025-01-18",
  },
  {
    id: "4",
    clientName: "João da Silva (MEI)",
    contractCode: "CT-2025/022",
    eci: "10291-MG",
    document: "111.222.333-44",
    status: "Novo",
    contractDate: "2025-01-25",
  },
  {
    id: "5",
    clientName: "Distribuidora Oeste",
    contractCode: "CT-2025/029",
    eci: "44501-RS",
    document: "55.666.777/0001-88",
    status: "Assinado",
    contractDate: "2025-01-28",
    signatureDate: "2025-01-30",
    callbackDate: "2025-01-31",
    pdfUrl: "/contracts/ct-2025-029.pdf",
  },
]
