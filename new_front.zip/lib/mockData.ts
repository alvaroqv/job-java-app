import type { DashboardData, User } from "@/types/dashboard";

export const mockDashboardData: DashboardData = {
  menuSections: [
    {
      title: "Dashboards",
      items: [
        {
          id: "fepweb",
          label: "FEPWeb",
          icon: "pi pi-th-large",
          submenu: [
            {
              id: "entities-sync",
              label: "Entities PC Sync",
              url: "/fepweb/entities-sync",
            },
            { id: "fepweb-jobs", label: "FEPWeb Jobs", url: "/fepweb/jobs" },
            {
              id: "fx-agreement",
              label: "FX Agreement",
              url: "/fepweb/fx-agreement",
            },
            {
              id: "fx-contracts",
              label: "FX Contracts",
              url: "/fepweb/fx-contracts",
            },
            {
              id: "other-contracts",
              label: "Other Contracts",
              url: "/fepweb/other-contracts",
            },
          ],
        },
        {
          id: "jd",
          label: "JD",
          icon: "pi pi-th-large",
          submenu: [
            { id: "pos-jobs", label: "POS Jobs", url: "/jd/pos-jobs" },
            { id: "ccs-jobs", label: "CCS Jobs", url: "/jd/ccs-jobs" },
            {
              id: "sisbajud-jobs",
              label: "SISBAJUD Jobs",
              url: "/jd/sisbajud-jobs",
            },
          ],
        },
      ],
    },
    {
      title: "Services",
      items: [
        {
          id: "fepweb-entity-sync",
          label: "FEPWeb Entity Sync",
          icon: "pi pi-plus-circle",
          url: "/services/entity-sync",
        },
        {
          id: "supplier-registry",
          label: "Supplier Registry",
          icon: "pi pi-plus-circle",
          url: "/services/supplier-registry",
        },
        {
          id: "entities-documents",
          label: "Entities Documents",
          icon: "pi pi-inbox",
          url: "/services/documents",
        },
      ],
    },
    {
      title: "Resources",
      items: [
        {
          id: "list-jobs",
          label: "List Jobs",
          icon: "pi pi-list",
          url: "/resources/jobs",
        },
        {
          id: "new-job",
          label: "New Job",
          icon: "pi pi-plus-circle",
          url: "/resources/new-job",
        },
        {
          id: "db-connections",
          label: "DB Connections",
          icon: "pi pi-database",
          url: "/resources/db-connections",
        },
        {
          id: "download-reports",
          label: "Download Reports",
          icon: "pi pi-download",
          url: "/resources/reports",
        },
      ],
    },
  ],
};

export const mockUser: User = {
  id: "1",
  name: "John Doe",
  email: "john.doe@example.com",
};
