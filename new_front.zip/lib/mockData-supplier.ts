import type { Supplier, SupplierVerificationResult } from "@/types/supplier"

export const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

// Mock CNPJ that exists in the database
export const MOCK_EXISTING_CNPJ = "00.000.000/0001-99"

export const mockExistingSupplier: Supplier = {
  id: "1",
  cnpj: MOCK_EXISTING_CNPJ,
  name: "Fornecedor Global Ltda (Dados do Banco)",
  createdAt: "2024-01-15",
  updatedAt: "2024-01-15",
  status: "Ativo",
}

export const mockSupplierData = {
  verifyCNPJ: async (cnpj: string): Promise<SupplierVerificationResult> => {
    await delay(800)

    if (cnpj === MOCK_EXISTING_CNPJ) {
      return {
        exists: true,
        supplier: mockExistingSupplier,
        message: "Fornecedor Encontrado!",
      }
    }

    return {
      exists: false,
      message: "CNPJ Disponível!",
    }
  },

  createSupplier: async (data: { cnpj: string; name: string }): Promise<Supplier> => {
    await delay(500)

    return {
      id: Math.random().toString(36).substr(2, 9),
      cnpj: data.cnpj,
      name: data.name,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: "Ativo",
    }
  },

  updateSupplier: async (id: string, data: { name: string }): Promise<Supplier> => {
    await delay(500)

    return {
      ...mockExistingSupplier,
      name: data.name,
      updatedAt: new Date().toISOString(),
    }
  },
}
