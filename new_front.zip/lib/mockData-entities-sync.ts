import type {
  JobExecution,
  Job,
  Report,
  DatabaseConnection,
  EntitiesSyncStats,
} from "@/types/jobs-sync";

export const mockEntitiesSyncStats: EntitiesSyncStats = {
  running: 3,
  success24h: 142,
  errors24h: 2,
};

export const mockJobExecutions: JobExecution[] = [
  {
    id: "1",
    status: "success",
    jobName: "Relatório Vendas",
    area: "Comercial",
    startTime: "30/11 14:00",
  },
  {
    id: "2",
    status: "error",
    jobName: "Sync Estoque",
    area: "Logística",
    startTime: "30/11 13:55",
  },
  {
    id: "3",
    status: "running",
    jobName: "Fechamento",
    area: "Financ.",
    startTime: "30/11 13:50",
  },
];

export const mockJobs: Job[] = [
  {
    id: "1",
    name: "Relatório Vendas",
    type: "SQL",
    cron: "0 8 * * 1",
  },
  {
    id: "2",
    name: "Sync Estoque",
    type: "Python",
    cron: "0 */4 * * *",
  },
];

export const mockReports: Report[] = [
  {
    id: "1",
    jobName: "Relatório Vendas",
    generationDate: "30/11/2025 14:05",
    size: "2.4 MB",
  },
  {
    id: "2",
    jobName: "Sync Estoque",
    generationDate: "29/11/2025 10:30",
    size: "1.8 MB",
  },
];

export const mockDatabaseConnections: DatabaseConnection[] = [
  {
    id: "1",
    name: "Oracle Produção",
    driver: "Oracle DB",
    host: "192.168.0.50",
    database: "DBPROD",
    port: "1521",
    username: "admin",
  },
];
