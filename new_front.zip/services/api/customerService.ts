import type {
  CustomerListResponse,
  CustomerFilters,
  Customer,
} from "@/types/customer";
import { mockCustomerListResponse, delay } from "@/lib/mockData-customer";

export const customerService = {
  // Get all customers with KPIs
  async getCustomers(filters?: CustomerFilters): Promise<CustomerListResponse> {
    // TODO: Replace with real API call when backend is ready
    // return apiClient.get('/customers', { params: filters })

    await delay(500);

    let filteredCustomers = mockCustomerListResponse.customers;

    if (filters?.search) {
      const searchLower = filters.search.toLowerCase();
      filteredCustomers = filteredCustomers.filter(
        (customer) =>
          customer.name.toLowerCase().includes(searchLower) ||
          customer.cnpjCpf.includes(searchLower) ||
          customer.email.toLowerCase().includes(searchLower)
      );
    }

    if (filters?.status && filters.status !== "all") {
      filteredCustomers = filteredCustomers.filter(
        (customer) => customer.status === filters.status
      );
    }

    return {
      ...mockCustomerListResponse,
      customers: filteredCustomers,
      totalRecords: filteredCustomers.length,
    };
  },

  // Update customer status
  async updateCustomerStatus(
    customerId: string,
    status: "Ativo" | "Inativo"
  ): Promise<Customer> {
    // TODO: Replace with real API call
    // return apiClient.patch(`/customers/${customerId}/status`, { status })

    await delay(300);

    const customer = mockCustomerListResponse.customers.find(
      (c) => c.id === customerId
    );
    if (!customer) throw new Error("Customer not found");

    return { ...customer, status };
  },

  // Delete customer
  async deleteCustomer(customerId: string): Promise<void> {
    // TODO: Replace with real API call
    // return apiClient.delete(`/customers/${customerId}`)

    await delay(300);
  },
};
