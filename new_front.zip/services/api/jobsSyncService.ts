import type {
  JobExecution,
  Job,
  Report,
  DatabaseConnection,
  EntitiesSyncStats,
} from "@/types/jobs-sync";
import {
  mockEntitiesSyncStats,
  mockJobExecutions,
  mockJobs,
  mockReports,
  mockDatabaseConnections,
} from "@/lib/mockData-entities-sync";

export const entitiesSyncService = {
  getStats: async (): Promise<EntitiesSyncStats> => {
    // Real API call (uncomment when ready):
    // const response = await apiClient.get('/api/entities-sync/stats')
    // return response.data

    // Mock data:
    return new Promise((resolve) => {
      setTimeout(() => resolve(mockEntitiesSyncStats), 500);
    });
  },

  getJobExecutions: async (): Promise<JobExecution[]> => {
    // Real API call:
    // const response = await apiClient.get('/api/entities-sync/executions')
    // return response.data

    // Mock data:
    return new Promise((resolve) => {
      setTimeout(() => resolve(mockJobExecutions), 500);
    });
  },

  getJobs: async (): Promise<Job[]> => {
    // Real API call:
    // const response = await apiClient.get('/api/entities-sync/jobs')
    // return response.data

    // Mock data:
    return new Promise((resolve) => {
      setTimeout(() => resolve(mockJobs), 500);
    });
  },

  getReports: async (): Promise<Report[]> => {
    // Real API call:
    // const response = await apiClient.get('/api/entities-sync/reports')
    // return response.data

    // Mock data:
    return new Promise((resolve) => {
      setTimeout(() => resolve(mockReports), 500);
    });
  },

  getDatabaseConnections: async (): Promise<DatabaseConnection[]> => {
    // Real API call:
    // const response = await apiClient.get('/api/entities-sync/connections')
    // return response.data

    // Mock data:
    return new Promise((resolve) => {
      setTimeout(() => resolve(mockDatabaseConnections), 500);
    });
  },

  deleteJob: async (jobId: string): Promise<void> => {
    // Real API call:
    // await apiClient.delete(`/api/entities-sync/jobs/${jobId}`)

    // Mock implementation:
    return new Promise((resolve) => {
      setTimeout(() => resolve(), 500);
    });
  },

  runJob: async (jobId: string): Promise<void> => {
    // Real API call:
    // await apiClient.post(`/api/entities-sync/jobs/${jobId}/run`)

    // Mock implementation:
    return new Promise((resolve) => {
      setTimeout(() => resolve(), 500);
    });
  },
};
