import type { Contract, ContractStats, ContractFilters, ContractSearchResponse } from "@/types/contract"
import { mockContracts, mockContractStats } from "@/lib/mockData-contract"

export const contractService = {
  // Get contract statistics
  getStats: async (): Promise<ContractStats> => {
    // Real API call (uncomment when ready):
    // const response = await apiClient.get<ContractStats>('/contracts/stats');
    // return response.data;

    // Mock implementation
    return new Promise((resolve) => {
      setTimeout(() => resolve(mockContractStats), 500)
    })
  },

  // Search contracts with filters
  searchContracts: async (filters: ContractFilters): Promise<ContractSearchResponse> => {
    // Real API call (uncomment when ready):
    // const response = await apiClient.get<ContractSearchResponse>('/contracts/search', { params: filters });
    // return response.data;

    // Mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        let filtered = [...mockContracts]

        if (filters.search) {
          const searchLower = filters.search.toLowerCase()
          filtered = filtered.filter(
            (c) => c.clientName.toLowerCase().includes(searchLower) || c.eci.toLowerCase().includes(searchLower),
          )
        }

        if (filters.document) {
          filtered = filtered.filter((c) => c.document.includes(filters.document!))
        }

        if (filters.status) {
          filtered = filtered.filter((c) => c.status === filters.status)
        }

        if (filters.startDate) {
          filtered = filtered.filter((c) => c.contractDate >= filters.startDate!)
        }

        if (filters.endDate) {
          filtered = filtered.filter((c) => c.contractDate <= filters.endDate!)
        }

        resolve({
          contracts: filtered,
          total: mockContracts.length,
          filtered: filtered.length,
        })
      }, 300)
    })
  },

  // Create new contract
  createContract: async (contractData: Partial<Contract>): Promise<Contract> => {
    // Real API call (uncomment when ready):
    // const response = await apiClient.post<Contract>('/contracts', contractData);
    // return response.data;

    // Mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        const newContract: Contract = {
          id: String(mockContracts.length + 1),
          clientName: contractData.clientName || "",
          contractCode: `CT-2025/${String(mockContracts.length + 1).padStart(3, "0")}`,
          eci: contractData.eci || "",
          document: contractData.document || "",
          status: "Novo",
          contractDate: new Date().toISOString().split("T")[0],
        }
        resolve(newContract)
      }, 500)
    })
  },

  // Export contracts
  exportContracts: async (format: "excel" | "pdf", filters: ContractFilters): Promise<Blob> => {
    // Real API call (uncomment when ready):
    // const response = await apiClient.get(`/contracts/export/${format}`, {
    //   params: filters,
    //   responseType: 'blob',
    // });
    // return response.data;

    // Mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        const blob = new Blob(["Mock export data"], { type: "application/octet-stream" })
        resolve(blob)
      }, 1000)
    })
  },
}
