import type { DashboardData, User } from "@/types/dashboard";
import { mockDashboardData, mockUser } from "@/lib/mockData";

// Simulate API delay
const simulateDelay = (ms = 1) =>
  new Promise((resolve) => setTimeout(resolve, ms));

export const dashboardService = {
  // Fetch dashboard menu data
  getDashboardData: async (): Promise<DashboardData> => {
    try {
      // When API is ready, uncomment this:
      // return await apiClient.get<DashboardData>('/dashboard/menu');

      // Mock implementation
      await simulateDelay();
      return mockDashboardData;
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      throw error;
    }
  },

  // Fetch user data
  getUserData: async (): Promise<User> => {
    try {
      // When API is ready, uncomment this:
      // return await apiClient.get<User>('/user/profile');

      // Mock implementation
      await simulateDelay();
      return mockUser;
    } catch (error) {
      console.error("Error fetching user data:", error);
      throw error;
    }
  },
};
