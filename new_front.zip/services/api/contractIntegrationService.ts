import type {
  ContractIntegration,
  ContractIntegrationStats,
  ContractIntegrationFilters,
} from "@/types/contract-integration"
import { mockContractIntegrations, mockContractIntegrationStats } from "@/lib/mockData-contract-integration"

export const contractIntegrationService = {
  getStats: async (): Promise<ContractIntegrationStats> => {
    // TODO: Replace with actual API call when backend is ready
    // return apiClient.get<ContractIntegrationStats>('/api/contract-integration/stats');
    return new Promise((resolve) => {
      setTimeout(() => resolve(mockContractIntegrationStats), 500)
    })
  },

  getContracts: async (filters: ContractIntegrationFilters): Promise<ContractIntegration[]> => {
    // TODO: Replace with actual API call when backend is ready
    // return apiClient.get<ContractIntegration[]>('/api/contract-integration', { params: filters });
    return new Promise((resolve) => {
      setTimeout(() => {
        let filtered = [...mockContractIntegrations]

        // Apply search filter
        if (filters.search) {
          const searchLower = filters.search.toLowerCase()
          filtered = filtered.filter(
            (contract) =>
              contract.contractNumber.toLowerCase().includes(searchLower) ||
              contract.boletaNumber.toLowerCase().includes(searchLower) ||
              contract.clientCnpj.includes(searchLower),
          )
        }

        // Apply status filter
        if (filters.status !== "all") {
          filtered = filtered.filter((contract) => contract.status === filters.status)
        }

        resolve(filtered)
      }, 500)
    })
  },

  retryImport: async (id: string): Promise<void> => {
    // TODO: Replace with actual API call when backend is ready
    // return apiClient.post(`/api/contract-integration/${id}/retry`);
    return new Promise((resolve) => {
      setTimeout(() => resolve(), 500)
    })
  },
}
