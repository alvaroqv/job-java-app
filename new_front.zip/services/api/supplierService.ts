import type { SupplierVerificationResult, Supplier } from "@/types/supplier";
import { mockSupplierData } from "@/lib/mockData-supplier";

export const supplierService = {
  // Verify if CNPJ exists
  async verifyCNPJ(cnpj: string): Promise<SupplierVerificationResult> {
    // TODO: Replace with real API call when backend is ready
    // return apiClient.post('/suppliers/verify', { cnpj })

    return mockSupplierData.verifyCNPJ(cnpj);
  },

  // Create new supplier
  async createSupplier(data: {
    cnpj: string;
    name: string;
  }): Promise<Supplier> {
    // TODO: Replace with real API call
    // return apiClient.post('/suppliers', data)

    return mockSupplierData.createSupplier(data);
  },

  // Update existing supplier
  async updateSupplier(id: string, data: { name: string }): Promise<Supplier> {
    // TODO: Replace with real API call
    // return apiClient.patch(`/suppliers/${id}`, data)

    return mockSupplierData.updateSupplier(id, data);
  },
};
