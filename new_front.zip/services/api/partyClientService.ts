import type { PartyClientSearchResponse, ImportResponse } from "@/types/party-client"
import { getPartyClientByECI } from "@/lib/mockData-party-client"

export const partyClientService = {
  // Search for a client in PartyClient external system by ECI
  searchByECI: async (eci: string): Promise<PartyClientSearchResponse> => {
    // TODO: Replace with actual API call when backend is ready
    // return apiClient.get<PartyClientSearchResponse>(`/api/party-client/search?eci=${eci}`);

    // Using mock data
    return new Promise((resolve) => {
      setTimeout(() => {
        const client = getPartyClientByECI(eci)

        if (client) {
          resolve({
            success: true,
            data: client,
          })
        } else {
          resolve({
            success: false,
            message: "Cliente não encontrado no PartyClient com este ECI.",
          })
        }
      }, 1000) // Simulate network delay
    })
  },

  // Import client data from PartyClient to local database
  importClient: async (eci: string): Promise<ImportResponse> => {
    // TODO: Replace with actual API call when backend is ready
    // return apiClient.post<ImportResponse>('/api/party-client/import', { eci });

    // Using mock data
    return new Promise((resolve) => {
      setTimeout(() => {
        const client = getPartyClientByECI(eci)

        if (client) {
          resolve({
            success: true,
            message: "Cliente importado com sucesso para a base local!",
            clientId: `local-${Date.now()}`,
          })
        } else {
          resolve({
            success: false,
            message: "Erro ao importar cliente.",
          })
        }
      }, 1000)
    })
  },
}
