"use client"

import { useState } from "react"
import { useDashboardData } from "@/hooks/useDashboard"
import clsx from "clsx"

interface SidebarProps {
  isOpen: boolean
  isCollapsed: boolean
  onCollapse: () => void
  onExpand: () => void
}

export function Sidebar({ isOpen, isCollapsed, onCollapse, onExpand }: SidebarProps) {
  const { data: dashboardData, isLoading } = useDashboardData()
  const [activeSubmenu, setActiveSubmenu] = useState<string | null>(null)

  const toggleSubmenu = (itemId: string) => {
    setActiveSubmenu(activeSubmenu === itemId ? null : itemId)
  }

  if (isLoading) {
    return (
      <nav className={clsx("sidebar", { close: !isOpen || isCollapsed })}>
        <div className="menu_content">
          <p style={{ color: "white", padding: "20px" }}>Loading...</p>
        </div>
      </nav>
    )
  }

  return (
    <nav className={clsx("sidebar", { close: !isOpen || isCollapsed })}>
      <div className="menu_content">
        {dashboardData?.menuSections.map((section) => (
          <ul key={section.title} className="menu_items">
            <div className="menu_title menu_title_before">{section.title}</div>
            {section.items.map((item) => (
              <li key={item.id} className="item">
                {item.submenu ? (
                  <>
                    <div
                      className={clsx("nav_link submenu_item", {
                        show_submenu: activeSubmenu === item.id,
                      })}
                      onClick={() => toggleSubmenu(item.id)}
                    >
                      <span className="navlink_icon">
                        <i className={item.icon}></i>
                      </span>
                      <span className="navlink">{item.label}</span>
                      <i className="pi pi-chevron-right arrow-left"></i>
                    </div>
                    <ul className="menu_items submenu">
                      {item.submenu.map((subitem) => (
                        <a key={subitem.id} href={subitem.url} className="nav_link sublink">
                          {subitem.label}
                        </a>
                      ))}
                    </ul>
                  </>
                ) : (
                  <a href={item.url} className="nav_link">
                    <span className="navlink_icon">
                      <i className={item.icon}></i>
                    </span>
                    <span className="navlink">{item.label}</span>
                  </a>
                )}
              </li>
            ))}
          </ul>
        ))}

        <div className="bottom_content">
          {!isCollapsed ? (
            <div className="bottom collapse_sidebar" onClick={onCollapse}>
              <span>Collapse</span>
              <i className="pi pi-sign-out"></i>
            </div>
          ) : (
            <div className="bottom expand_sidebar" onClick={onExpand}>
              <span>Expand</span>
              <i className="pi pi-sign-in"></i>
            </div>
          )}
        </div>
      </div>
    </nav>
  )
}
