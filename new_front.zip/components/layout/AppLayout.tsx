"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Navbar } from "./Navbar"
import { Sidebar } from "./Sidebar"

interface AppLayoutProps {
  children: React.ReactNode
}

export function AppLayout({ children }: AppLayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false)
  const [isDarkMode, setIsDarkMode] = useState(false)

  // Handle responsive behavior
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setIsSidebarOpen(false)
      } else {
        setIsSidebarOpen(true)
      }
    }

    handleResize()
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  // Apply dark mode
  useEffect(() => {
    if (isDarkMode) {
      document.body.classList.add("dark")
    } else {
      document.body.classList.remove("dark")
    }
  }, [isDarkMode])

  const handleMenuToggle = () => {
    setIsSidebarOpen(!isSidebarOpen)
  }

  const handleThemeToggle = () => {
    setIsDarkMode(!isDarkMode)
  }

  const handleCollapse = () => {
    setIsSidebarCollapsed(true)
  }

  const handleExpand = () => {
    setIsSidebarCollapsed(false)
  }

  return (
    <>
      <Navbar onMenuToggle={handleMenuToggle} onThemeToggle={handleThemeToggle} isDark={isDarkMode} />
      <Sidebar
        isOpen={isSidebarOpen}
        isCollapsed={isSidebarCollapsed}
        onCollapse={handleCollapse}
        onExpand={handleExpand}
      />
      <main className="main-content">{children}</main>
    </>
  )
}
