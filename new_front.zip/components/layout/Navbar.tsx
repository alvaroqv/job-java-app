"use client"

import { useState } from "react"
import { useUserData } from "@/hooks/useDashboard"

interface NavbarProps {
  onMenuToggle: () => void
  onThemeToggle: () => void
  isDark: boolean
}

export function Navbar({ onMenuToggle, onThemeToggle, isDark }: NavbarProps) {
  const { data: user } = useUserData()
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <nav className="navbar">
      <div className="logo_item">
        <i className="pi pi-bars" id="sidebarOpen" onClick={onMenuToggle}></i>
        <img
          src="/images/logo.png"
          alt="Logo"
          onError={(e) => {
            ;(e.target as HTMLImageElement).style.display = "none"
          }}
        />
        Lexus Page
      </div>

      <div className="search_bar">
        <input
          type="text"
          placeholder="How can help you today?"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="navbar_content">
        <i className="pi pi-th-large"></i>
        <i className={isDark ? "pi pi-moon" : "pi pi-sun"} id="darkLight" onClick={onThemeToggle}></i>
        <i className="pi pi-bell"></i>
        <i className="pi pi-user" title={user?.name || "User"}></i>
      </div>
    </nav>
  )
}
