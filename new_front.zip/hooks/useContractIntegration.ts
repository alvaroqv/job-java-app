import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { contractIntegrationService } from "@/services/api/contractIntegrationService"
import type { ContractIntegrationFilters } from "@/types/contract-integration"

export const useContractIntegration = (filters: ContractIntegrationFilters) => {
  const queryClient = useQueryClient()

  const statsQuery = useQuery({
    queryKey: ["contract-integration-stats"],
    queryFn: () => contractIntegrationService.getStats(),
  })

  const contractsQuery = useQuery({
    queryKey: ["contract-integrations", filters],
    queryFn: () => contractIntegrationService.getContracts(filters),
  })

  const retryImportMutation = useMutation({
    mutationFn: (id: string) => contractIntegrationService.retryImport(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["contract-integrations"] })
      queryClient.invalidateQueries({ queryKey: ["contract-integration-stats"] })
    },
  })

  return {
    stats: statsQuery.data,
    contracts: contractsQuery.data || [],
    isLoading: statsQuery.isLoading || contractsQuery.isLoading,
    retryImport: retryImportMutation.mutate,
    isRetrying: retryImportMutation.isPending,
  }
}
