import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { entitiesSyncService } from "@/services/api/jobsSyncService";

export function useEntitiesSyncStats() {
  return useQuery({
    queryKey: ["entities-sync-stats"],
    queryFn: entitiesSyncService.getStats,
  });
}

export function useJobExecutions() {
  return useQuery({
    queryKey: ["job-executions"],
    queryFn: entitiesSyncService.getJobExecutions,
  });
}

export function useJobs() {
  return useQuery({
    queryKey: ["jobs"],
    queryFn: entitiesSyncService.getJobs,
  });
}

export function useReports() {
  return useQuery({
    queryKey: ["reports"],
    queryFn: entitiesSyncService.getReports,
  });
}

export function useDatabaseConnections() {
  return useQuery({
    queryKey: ["database-connections"],
    queryFn: entitiesSyncService.getDatabaseConnections,
  });
}

export function useDeleteJob() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: entitiesSyncService.deleteJob,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["jobs"] });
    },
  });
}

export function useRunJob() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: entitiesSyncService.runJob,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["job-executions"] });
    },
  });
}
