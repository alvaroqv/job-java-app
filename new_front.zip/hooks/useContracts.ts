import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { contractService } from "@/services/api/contractService"
import type { ContractFilters, Contract } from "@/types/contract"

export const useContracts = (filters: ContractFilters) => {
  const queryClient = useQueryClient()

  // Get contract statistics
  const { data: stats } = useQuery({
    queryKey: ["contracts", "stats"],
    queryFn: () => contractService.getStats(),
  })

  // Search contracts
  const { data: searchResults, isLoading } = useQuery({
    queryKey: ["contracts", "search", filters],
    queryFn: () => contractService.searchContracts(filters),
  })

  // Create contract mutation
  const createContractMutation = useMutation({
    mutationFn: (contractData: Partial<Contract>) => contractService.createContract(contractData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["contracts"] })
    },
  })

  // Export contracts mutation
  const exportMutation = useMutation({
    mutationFn: ({ format, filters }: { format: "excel" | "pdf"; filters: ContractFilters }) =>
      contractService.exportContracts(format, filters),
  })

  return {
    stats,
    contracts: searchResults?.contracts || [],
    total: searchResults?.total || 0,
    filtered: searchResults?.filtered || 0,
    isLoading,
    createContract: createContractMutation.mutate,
    exportContracts: exportMutation.mutate,
  }
}
