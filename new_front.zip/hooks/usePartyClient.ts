import { useMutation, useQueryClient } from "@tanstack/react-query"
import { partyClientService } from "@/services/api/partyClientService"

export const usePartyClient = () => {
  const queryClient = useQueryClient()

  const searchMutation = useMutation({
    mutationFn: (eci: string) => partyClientService.searchByECI(eci),
  })

  const importMutation = useMutation({
    mutationFn: (eci: string) => partyClientService.importClient(eci),
    onSuccess: () => {
      // Invalidate customers cache after import
      queryClient.invalidateQueries({ queryKey: ["customers"] })
    },
  })

  return {
    search: searchMutation.mutateAsync,
    isSearching: searchMutation.isPending,
    import: importMutation.mutateAsync,
    isImporting: importMutation.isPending,
  }
}
