import { useQuery } from "@tanstack/react-query"
import { dashboardService } from "@/services/api/dashboardService"

export const useDashboardData = () => {
  return useQuery({
    queryKey: ["dashboard"],
    queryFn: dashboardService.getDashboardData,
    staleTime: 1000 * 60 * 5, // 5 minutes
  })
}

export const useUserData = () => {
  return useQuery({
    queryKey: ["user"],
    queryFn: dashboardService.getUserData,
    staleTime: 1000 * 60 * 10, // 10 minutes
  })
}
