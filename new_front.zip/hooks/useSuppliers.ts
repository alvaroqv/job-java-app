import { useMutation, useQueryClient } from "@tanstack/react-query"
import { supplierService } from "@/services/api/supplierService"

export function useVerifyCNPJ() {
  return useMutation({
    mutationFn: (cnpj: string) => supplierService.verifyCNPJ(cnpj),
  })
}

export function useCreateSupplier() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (data: { cnpj: string; name: string }) => supplierService.createSupplier(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["suppliers"] })
    },
  })
}

export function useUpdateSupplier() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ id, name }: { id: string; name: string }) => supplierService.updateSupplier(id, { name }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["suppliers"] })
    },
  })
}
