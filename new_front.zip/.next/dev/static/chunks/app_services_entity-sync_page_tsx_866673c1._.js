(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_cb84c0c7._.js",
  "static/chunks/_bb2e2c07._.js",
  "static/chunks/app_services_entity-sync_entity-sync_93b336e3.css"
],
    source: "dynamic"
});
