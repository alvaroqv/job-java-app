(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_primereact_datatable_datatable_esm_e833540e.js",
  "static/chunks/node_modules_primereact_8ae91937._.js",
  "static/chunks/node_modules_c1e50f83._.js",
  "static/chunks/_e79ff0fa._.js",
  "static/chunks/app_fepweb_entities-sync_entities-sync_5ca3f9e4.css"
],
    source: "dynamic"
});
