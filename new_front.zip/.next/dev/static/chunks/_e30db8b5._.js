(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/mockData-contract.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mockContractStats",
    ()=>mockContractStats,
    "mockContracts",
    ()=>mockContracts
]);
const mockContractStats = {
    newContracts: 12,
    pendingSignature: 8,
    signed: 145
};
const mockContracts = [
    {
        id: "1",
        clientName: "Tech Solutions S.A.",
        contractCode: "CT-2025/001",
        eci: "90210-BR",
        document: "12.345.678/0001-90",
        status: "Assinado",
        contractDate: "2025-01-10",
        signatureDate: "2025-01-15",
        callbackDate: "2025-01-16",
        pdfUrl: "/contracts/ct-2025-001.pdf"
    },
    {
        id: "2",
        clientName: "Grupo Alpha Retail",
        contractCode: "CT-2025/008",
        eci: "55021-RJ",
        document: "33.444.555/0001-22",
        status: "Assinado",
        contractDate: "2025-01-12",
        signatureDate: "2025-01-20",
        pdfUrl: "/contracts/ct-2025-008.pdf"
    },
    {
        id: "3",
        clientName: "Mercado Silva Ltda",
        contractCode: "CT-2025/015",
        eci: "88848-SP",
        document: "98.765.432/0001-10",
        status: "Pendente",
        contractDate: "2025-01-18"
    },
    {
        id: "4",
        clientName: "João da Silva (MEI)",
        contractCode: "CT-2025/022",
        eci: "10291-MG",
        document: "111.222.333-44",
        status: "Novo",
        contractDate: "2025-01-25"
    },
    {
        id: "5",
        clientName: "Distribuidora Oeste",
        contractCode: "CT-2025/029",
        eci: "44501-RS",
        document: "55.666.777/0001-88",
        status: "Assinado",
        contractDate: "2025-01-28",
        signatureDate: "2025-01-30",
        callbackDate: "2025-01-31",
        pdfUrl: "/contracts/ct-2025-029.pdf"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/services/api/contractService.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "contractService",
    ()=>contractService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mockData$2d$contract$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/mockData-contract.ts [app-client] (ecmascript)");
;
const contractService = {
    // Get contract statistics
    getStats: async ()=>{
        // Real API call (uncomment when ready):
        // const response = await apiClient.get<ContractStats>('/contracts/stats');
        // return response.data;
        // Mock implementation
        return new Promise((resolve)=>{
            setTimeout(()=>resolve(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mockData$2d$contract$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockContractStats"]), 500);
        });
    },
    // Search contracts with filters
    searchContracts: async (filters)=>{
        // Real API call (uncomment when ready):
        // const response = await apiClient.get<ContractSearchResponse>('/contracts/search', { params: filters });
        // return response.data;
        // Mock implementation
        return new Promise((resolve)=>{
            setTimeout(()=>{
                let filtered = [
                    ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mockData$2d$contract$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockContracts"]
                ];
                if (filters.search) {
                    const searchLower = filters.search.toLowerCase();
                    filtered = filtered.filter((c)=>c.clientName.toLowerCase().includes(searchLower) || c.eci.toLowerCase().includes(searchLower));
                }
                if (filters.document) {
                    filtered = filtered.filter((c)=>c.document.includes(filters.document));
                }
                if (filters.status) {
                    filtered = filtered.filter((c)=>c.status === filters.status);
                }
                if (filters.startDate) {
                    filtered = filtered.filter((c)=>c.contractDate >= filters.startDate);
                }
                if (filters.endDate) {
                    filtered = filtered.filter((c)=>c.contractDate <= filters.endDate);
                }
                resolve({
                    contracts: filtered,
                    total: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mockData$2d$contract$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockContracts"].length,
                    filtered: filtered.length
                });
            }, 300);
        });
    },
    // Create new contract
    createContract: async (contractData)=>{
        // Real API call (uncomment when ready):
        // const response = await apiClient.post<Contract>('/contracts', contractData);
        // return response.data;
        // Mock implementation
        return new Promise((resolve)=>{
            setTimeout(()=>{
                const newContract = {
                    id: String(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mockData$2d$contract$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockContracts"].length + 1),
                    clientName: contractData.clientName || "",
                    contractCode: `CT-2025/${String(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mockData$2d$contract$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockContracts"].length + 1).padStart(3, "0")}`,
                    eci: contractData.eci || "",
                    document: contractData.document || "",
                    status: "Novo",
                    contractDate: new Date().toISOString().split("T")[0]
                };
                resolve(newContract);
            }, 500);
        });
    },
    // Export contracts
    exportContracts: async (format, filters)=>{
        // Real API call (uncomment when ready):
        // const response = await apiClient.get(`/contracts/export/${format}`, {
        //   params: filters,
        //   responseType: 'blob',
        // });
        // return response.data;
        // Mock implementation
        return new Promise((resolve)=>{
            setTimeout(()=>{
                const blob = new Blob([
                    "Mock export data"
                ], {
                    type: "application/octet-stream"
                });
                resolve(blob);
            }, 1000);
        });
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useContracts.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useContracts",
    ()=>useContracts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2f$contractService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/api/contractService.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
const useContracts = (filters)=>{
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    // Get contract statistics
    const { data: stats } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "contracts",
            "stats"
        ],
        queryFn: {
            "useContracts.useQuery": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2f$contractService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contractService"].getStats()
        }["useContracts.useQuery"]
    });
    // Search contracts
    const { data: searchResults, isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "contracts",
            "search",
            filters
        ],
        queryFn: {
            "useContracts.useQuery": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2f$contractService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contractService"].searchContracts(filters)
        }["useContracts.useQuery"]
    });
    // Create contract mutation
    const createContractMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useContracts.useMutation[createContractMutation]": (contractData)=>__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2f$contractService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contractService"].createContract(contractData)
        }["useContracts.useMutation[createContractMutation]"],
        onSuccess: {
            "useContracts.useMutation[createContractMutation]": ()=>{
                queryClient.invalidateQueries({
                    queryKey: [
                        "contracts"
                    ]
                });
            }
        }["useContracts.useMutation[createContractMutation]"]
    });
    // Export contracts mutation
    const exportMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useContracts.useMutation[exportMutation]": ({ format, filters })=>__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2f$contractService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contractService"].exportContracts(format, filters)
        }["useContracts.useMutation[exportMutation]"]
    });
    return {
        stats,
        contracts: searchResults?.contracts || [],
        total: searchResults?.total || 0,
        filtered: searchResults?.filtered || 0,
        isLoading,
        createContract: createContractMutation.mutate,
        exportContracts: exportMutation.mutate
    };
};
_s(useContracts, "4rvnAtuln/nnBlOyBCk4fejJHYE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/fepweb/fx-agreement/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FxAgreementPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$card$2f$card$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/card/card.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$datatable$2f$datatable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/datatable/datatable.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/column/column.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$inputtext$2f$inputtext$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/inputtext/inputtext.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$dropdown$2f$dropdown$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/dropdown/dropdown.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$calendar$2f$calendar$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/calendar/calendar.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$button$2f$button$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/button/button.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$tag$2f$tag$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/tag/tag.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$chip$2f$chip$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/chip/chip.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$menu$2f$menu$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/menu/menu.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContracts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContracts.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
function FxAgreementPage() {
    _s();
    const [filters, setFilters] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        status: "Assinado",
        startDate: "2025-01-01",
        endDate: "2025-01-31"
    });
    const { stats, contracts, total, filtered, isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContracts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContracts"])(filters);
    const statusOptions = [
        {
            label: "Todos",
            value: ""
        },
        {
            label: "Assinados",
            value: "Assinado"
        },
        {
            label: "Pendentes",
            value: "Pendente"
        },
        {
            label: "Novos",
            value: "Novo"
        }
    ];
    const handleFilterChange = (key, value)=>{
        setFilters((prev)=>({
                ...prev,
                [key]: value
            }));
    };
    const handleRemoveFilter = (key)=>{
        setFilters((prev)=>{
            const newFilters = {
                ...prev
            };
            delete newFilters[key];
            return newFilters;
        });
    };
    const clearAllFilters = ()=>{
        setFilters({});
    };
    const exportMenuItems = [
        {
            label: "Excel (.xls)",
            icon: "pi pi-file-excel",
            command: ()=>console.log("Export to Excel")
        },
        {
            label: "PDF",
            icon: "pi pi-file-pdf",
            command: ()=>console.log("Export to PDF")
        }
    ];
    const statusBodyTemplate = (rowData)=>{
        const statusConfig = {
            Assinado: {
                severity: "success",
                icon: "pi pi-check"
            },
            Pendente: {
                severity: "warning",
                icon: "pi pi-clock"
            },
            Novo: {
                severity: "info",
                icon: "pi pi-file"
            }
        };
        const config = statusConfig[rowData.status];
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$tag$2f$tag$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Tag"], {
            value: rowData.status,
            severity: config.severity,
            icon: config.icon,
            className: "status-badge"
        }, void 0, false, {
            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
            lineNumber: 70,
            columnNumber: 12
        }, this);
    };
    const clientBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "fw-bold",
                    children: rowData.clientName
                }, void 0, false, {
                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                    lineNumber: 76,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                    className: "text-muted",
                    children: rowData.contractCode
                }, void 0, false, {
                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                    lineNumber: 77,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
            lineNumber: 75,
            columnNumber: 7
        }, this);
    };
    const eciBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "eci-code",
            children: rowData.eci
        }, void 0, false, {
            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
            lineNumber: 83,
            columnNumber: 12
        }, this);
    };
    const callbackBodyTemplate = (rowData)=>{
        if (!rowData.callbackDate) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-muted",
                children: "-"
            }, void 0, false, {
                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                lineNumber: 88,
                columnNumber: 14
            }, this);
        }
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "callback-date",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                    className: "pi pi-clock me-1"
                }, void 0, false, {
                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                    lineNumber: 92,
                    columnNumber: 9
                }, this),
                new Date(rowData.callbackDate).toLocaleDateString("pt-BR")
            ]
        }, void 0, true, {
            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
            lineNumber: 91,
            columnNumber: 7
        }, this);
    };
    const actionsBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-end",
            children: rowData.pdfUrl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$button$2f$button$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                icon: "pi pi-file-pdf",
                className: "p-button-text p-button-danger",
                tooltip: "Visualizar PDF",
                tooltipOptions: {
                    position: "top"
                }
            }, void 0, false, {
                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                lineNumber: 102,
                columnNumber: 11
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
            lineNumber: 100,
            columnNumber: 7
        }, this);
    };
    const formatDate = (dateString)=>{
        if (!dateString) return "-";
        return new Date(dateString).toLocaleDateString("pt-BR");
    };
    const activeFilters = [];
    if (filters.status) {
        activeFilters.push({
            key: "status",
            label: `Status: ${filters.status}`
        });
    }
    if (filters.startDate && filters.endDate) {
        activeFilters.push({
            key: "dates",
            label: `Período: ${formatDate(filters.startDate)} - ${formatDate(filters.endDate)}`
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fx-agreement-page",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "page-header",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                className: "page-title",
                                children: "Gestão de Contratos"
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                lineNumber: 133,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "page-subtitle",
                                children: "Acompanhamento de assinaturas e status"
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                lineNumber: 134,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                        lineNumber: 132,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "header-actions",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$button$2f$button$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                label: "Novo Contrato",
                                icon: "pi pi-plus"
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                lineNumber: 137,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$button$2f$button$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                label: "Exportar",
                                icon: "pi pi-download",
                                className: "p-button-outlined",
                                onClick: (e)=>{
                                    const menu = document.querySelector(".export-menu");
                                    menu?.toggle(e);
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                lineNumber: 138,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$menu$2f$menu$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Menu"], {
                                model: exportMenuItems,
                                popup: true,
                                className: "export-menu"
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                lineNumber: 147,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                        lineNumber: 136,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                lineNumber: 131,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "kpi-cards",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$card$2f$card$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                        className: "kpi-card border-info",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "kpi-content",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "icon-box bg-info",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                        className: "pi pi-file"
                                    }, void 0, false, {
                                        fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                        lineNumber: 155,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 154,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h6", {
                                            className: "kpi-label",
                                            children: "Novos Contratos"
                                        }, void 0, false, {
                                            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                            lineNumber: 158,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "kpi-value",
                                            children: stats?.newContracts || 0
                                        }, void 0, false, {
                                            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                            lineNumber: 159,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 157,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                            lineNumber: 153,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                        lineNumber: 152,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$card$2f$card$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                        className: "kpi-card border-warning",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "kpi-content",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "icon-box bg-warning",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                        className: "pi pi-pencil"
                                    }, void 0, false, {
                                        fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                        lineNumber: 167,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 166,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h6", {
                                            className: "kpi-label",
                                            children: "Pendentes de Assinatura"
                                        }, void 0, false, {
                                            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                            lineNumber: 170,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "kpi-value",
                                            children: stats?.pendingSignature || 0
                                        }, void 0, false, {
                                            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                            lineNumber: 171,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 169,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                            lineNumber: 165,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                        lineNumber: 164,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$card$2f$card$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                        className: "kpi-card border-success",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "icon-box bg-success",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                    className: "pi pi-check-circle"
                                }, void 0, false, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 178,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                lineNumber: 177,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h6", {
                                        className: "kpi-label",
                                        children: "Contratos Assinados"
                                    }, void 0, false, {
                                        fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                        lineNumber: 181,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "kpi-value",
                                        children: stats?.signed || 0
                                    }, void 0, false, {
                                        fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                        lineNumber: 182,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                lineNumber: 180,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                        lineNumber: 176,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                lineNumber: 151,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$card$2f$card$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                className: "filters-card",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "filters-grid",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "filter-field",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "filter-label",
                                    children: "Busca Geral"
                                }, void 0, false, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 190,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$inputtext$2f$inputtext$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputText"], {
                                    placeholder: "Nome ou ECI...",
                                    value: filters.search || "",
                                    onChange: (e)=>handleFilterChange("search", e.target.value)
                                }, void 0, false, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 191,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                            lineNumber: 189,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "filter-field",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "filter-label",
                                    children: "Documento"
                                }, void 0, false, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 199,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$inputtext$2f$inputtext$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputText"], {
                                    placeholder: "CNPJ / CPF",
                                    value: filters.document || "",
                                    onChange: (e)=>handleFilterChange("document", e.target.value)
                                }, void 0, false, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 200,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                            lineNumber: 198,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "filter-field",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "filter-label",
                                    children: "Status"
                                }, void 0, false, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 208,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$dropdown$2f$dropdown$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dropdown"], {
                                    value: filters.status,
                                    options: statusOptions,
                                    onChange: (e)=>handleFilterChange("status", e.value),
                                    placeholder: "Todos"
                                }, void 0, false, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 209,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                            lineNumber: 207,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "filter-field",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "filter-label",
                                    children: "Data Início"
                                }, void 0, false, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 218,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$calendar$2f$calendar$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Calendar"], {
                                    value: filters.startDate ? new Date(filters.startDate) : null,
                                    onChange: (e)=>handleFilterChange("startDate", e.value?.toISOString().split("T")[0]),
                                    dateFormat: "dd/mm/yy"
                                }, void 0, false, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 219,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                            lineNumber: 217,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "filter-field",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "filter-label",
                                    children: "Data Fim"
                                }, void 0, false, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 227,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$calendar$2f$calendar$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Calendar"], {
                                    value: filters.endDate ? new Date(filters.endDate) : null,
                                    onChange: (e)=>handleFilterChange("endDate", e.value?.toISOString().split("T")[0]),
                                    dateFormat: "dd/mm/yy"
                                }, void 0, false, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 228,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                            lineNumber: 226,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "filter-field filter-button",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "filter-label",
                                    children: " "
                                }, void 0, false, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 236,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$button$2f$button$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    label: "Filtrar",
                                    icon: "pi pi-filter"
                                }, void 0, false, {
                                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                    lineNumber: 237,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                            lineNumber: 235,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                    lineNumber: 188,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                lineNumber: 187,
                columnNumber: 7
            }, this),
            activeFilters.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "active-filters",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "active-filters-label",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                className: "pi pi-filter"
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                lineNumber: 245,
                                columnNumber: 13
                            }, this),
                            " Filtros Ativos:"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                        lineNumber: 244,
                        columnNumber: 11
                    }, this),
                    activeFilters.map((filter)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$chip$2f$chip$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Chip"], {
                            label: filter.label,
                            removable: true,
                            onRemove: ()=>{
                                if (filter.key === "dates") {
                                    handleRemoveFilter("startDate");
                                    handleRemoveFilter("endDate");
                                } else {
                                    handleRemoveFilter(filter.key);
                                }
                            },
                            className: "active-filter-chip"
                        }, filter.key, false, {
                            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                            lineNumber: 248,
                            columnNumber: 13
                        }, this)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$button$2f$button$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        label: "Limpar tudo",
                        className: "p-button-text p-button-danger p-button-sm",
                        onClick: clearAllFilters
                    }, void 0, false, {
                        fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                        lineNumber: 263,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                lineNumber: 243,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$card$2f$card$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                className: "table-card",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$datatable$2f$datatable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DataTable"], {
                        value: contracts,
                        loading: isLoading,
                        paginator: true,
                        rows: 10,
                        className: "contracts-table",
                        emptyMessage: "Nenhum contrato encontrado",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Column"], {
                                field: "clientName",
                                header: "Nome do Cliente",
                                body: clientBodyTemplate
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                lineNumber: 276,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Column"], {
                                field: "eci",
                                header: "ECI",
                                body: eciBodyTemplate
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                lineNumber: 277,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Column"], {
                                field: "document",
                                header: "CNPJ / CPF"
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                lineNumber: 278,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Column"], {
                                field: "status",
                                header: "Situação",
                                body: statusBodyTemplate
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                lineNumber: 279,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Column"], {
                                field: "contractDate",
                                header: "Data Contrato",
                                body: (data)=>formatDate(data.contractDate)
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                lineNumber: 280,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Column"], {
                                field: "signatureDate",
                                header: "Data Assinatura",
                                body: (data)=>formatDate(data.signatureDate)
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                lineNumber: 281,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Column"], {
                                field: "callbackDate",
                                header: "Data CallBack",
                                body: callbackBodyTemplate
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                lineNumber: 282,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Column"], {
                                header: "Ações",
                                body: actionsBodyTemplate,
                                className: "text-end"
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                                lineNumber: 283,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                        lineNumber: 268,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "table-footer",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                            className: "text-muted",
                            children: [
                                "Mostrando ",
                                filtered,
                                " resultados ",
                                filtered !== total && `(filtrado de ${total})`
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                            lineNumber: 287,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                        lineNumber: 286,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
                lineNumber: 267,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/fepweb/fx-agreement/page.tsx",
        lineNumber: 130,
        columnNumber: 5
    }, this);
}
_s(FxAgreementPage, "OZEkml1tL2ry+D27kVlFdn4pQVE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContracts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContracts"]
    ];
});
_c = FxAgreementPage;
var _c;
__turbopack_context__.k.register(_c, "FxAgreementPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_e30db8b5._.js.map