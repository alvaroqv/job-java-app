(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_140ba204._.js",
  "static/chunks/node_modules_primereact_datatable_datatable_esm_e833540e.js",
  "static/chunks/node_modules_primereact_ec438734._.js",
  "static/chunks/node_modules_57b33c64._.js"
],
    source: "dynamic"
});
