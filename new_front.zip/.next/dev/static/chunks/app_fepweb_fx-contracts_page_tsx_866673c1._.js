(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_primereact_datatable_datatable_esm_e833540e.js",
  "static/chunks/node_modules_primereact_2bb96bc3._.js",
  "static/chunks/node_modules_57b33c64._.js",
  "static/chunks/_573a952c._.js",
  "static/chunks/app_fepweb_fx-contracts_fx-contracts_8aa4ec22.css"
],
    source: "dynamic"
});
