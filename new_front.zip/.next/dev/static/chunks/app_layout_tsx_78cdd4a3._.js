(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__a3241c11._.css",
  "static/chunks/node_modules_58f229a1._.js",
  "static/chunks/_e3936bc5._.js"
],
    source: "dynamic"
});
