(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_303ea6b2._.js",
  "static/chunks/_35731c68._.js",
  "static/chunks/app_services_supplier-registry_supplier-registry_5f75e4a2.css"
],
    source: "dynamic"
});
