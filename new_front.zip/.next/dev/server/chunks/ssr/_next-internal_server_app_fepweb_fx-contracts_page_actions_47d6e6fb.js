module.exports = [
"[project]/.next-internal/server/app/fepweb/fx-contracts/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_fepweb_fx-contracts_page_actions_47d6e6fb.js.map