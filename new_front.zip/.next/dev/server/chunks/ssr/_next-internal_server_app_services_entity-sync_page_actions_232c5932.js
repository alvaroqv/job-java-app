module.exports = [
"[project]/.next-internal/server/app/services/entity-sync/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_services_entity-sync_page_actions_232c5932.js.map