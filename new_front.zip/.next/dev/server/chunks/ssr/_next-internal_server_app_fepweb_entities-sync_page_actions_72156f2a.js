module.exports = [
"[project]/.next-internal/server/app/fepweb/entities-sync/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_fepweb_entities-sync_page_actions_72156f2a.js.map