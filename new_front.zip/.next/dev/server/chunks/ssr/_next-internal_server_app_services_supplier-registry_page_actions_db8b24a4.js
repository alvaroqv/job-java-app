module.exports = [
"[project]/.next-internal/server/app/services/supplier-registry/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_services_supplier-registry_page_actions_db8b24a4.js.map