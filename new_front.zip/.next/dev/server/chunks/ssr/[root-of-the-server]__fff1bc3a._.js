module.exports = [
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/lib/mockData-customer.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "delay",
    ()=>delay,
    "mockCustomerKPIs",
    ()=>mockCustomerKPIs,
    "mockCustomerListResponse",
    ()=>mockCustomerListResponse,
    "mockCustomers",
    ()=>mockCustomers
]);
const mockCustomerKPIs = {
    newRegistrations: {
        count: 24,
        percentageChange: 12
    },
    updates: {
        count: 156
    },
    deactivations: {
        count: 5
    },
    reactivations: {
        count: 12
    }
};
const mockCustomers = [
    {
        id: "1",
        name: "Tech Solutions Ltda",
        email: "contato@techsol.com",
        eci: "ECI-9021",
        cnpjCpf: "12.345.678/0001-90",
        createdAt: "2025-01-10",
        updatedAt: "2025-02-08",
        status: "Ativo",
        situation: "Regular",
        avatar: "T"
    },
    {
        id: "2",
        name: "Mercado Silva",
        email: "financeiro@msilva.com",
        eci: "ECI-8840",
        cnpjCpf: "98.765.432/0001-10",
        createdAt: "2024-11-15",
        updatedAt: "2024-11-30",
        status: "Inativo",
        situation: "Bloqueado",
        avatar: "M"
    },
    {
        id: "3",
        name: "João da Silva (MEI)",
        email: "joao@email.com",
        eci: "ECI-1029",
        cnpjCpf: "111.222.333-44",
        createdAt: "2025-02-01",
        updatedAt: "2025-02-01",
        status: "Ativo",
        situation: "Em Análise",
        avatar: "J"
    },
    {
        id: "4",
        name: "Indústria XYZ S.A.",
        email: "comercial@xyz.com.br",
        eci: "ECI-7755",
        cnpjCpf: "22.333.444/0001-55",
        createdAt: "2024-12-20",
        updatedAt: "2025-01-15",
        status: "Ativo",
        situation: "Regular",
        avatar: "I"
    },
    {
        id: "5",
        name: "Maria Comércio LTDA",
        email: "maria@comercio.com",
        eci: "ECI-6622",
        cnpjCpf: "33.444.555/0001-66",
        createdAt: "2025-01-05",
        updatedAt: "2025-01-28",
        status: "Ativo",
        situation: "Regular",
        avatar: "M"
    }
];
const mockCustomerListResponse = {
    customers: mockCustomers,
    kpis: mockCustomerKPIs,
    totalRecords: mockCustomers.length
};
const delay = (ms)=>new Promise((resolve)=>setTimeout(resolve, ms));
}),
"[project]/services/api/customerService.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "customerService",
    ()=>customerService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mockData$2d$customer$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/mockData-customer.ts [app-rsc] (ecmascript)");
;
const customerService = {
    // Get all customers with KPIs
    async getCustomers (filters) {
        // TODO: Replace with real API call when backend is ready
        // return apiClient.get('/customers', { params: filters })
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mockData$2d$customer$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["delay"])(500);
        let filteredCustomers = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mockData$2d$customer$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["mockCustomerListResponse"].customers;
        if (filters?.search) {
            const searchLower = filters.search.toLowerCase();
            filteredCustomers = filteredCustomers.filter((customer)=>customer.name.toLowerCase().includes(searchLower) || customer.cnpjCpf.includes(searchLower) || customer.email.toLowerCase().includes(searchLower));
        }
        if (filters?.status && filters.status !== "all") {
            filteredCustomers = filteredCustomers.filter((customer)=>customer.status === filters.status);
        }
        return {
            ...__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mockData$2d$customer$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["mockCustomerListResponse"],
            customers: filteredCustomers,
            totalRecords: filteredCustomers.length
        };
    },
    // Update customer status
    async updateCustomerStatus (customerId, status) {
        // TODO: Replace with real API call
        // return apiClient.patch(`/customers/${customerId}/status`, { status })
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mockData$2d$customer$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["delay"])(300);
        const customer = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mockData$2d$customer$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["mockCustomerListResponse"].customers.find((c)=>c.id === customerId);
        if (!customer) throw new Error("Customer not found");
        return {
            ...customer,
            status
        };
    },
    // Delete customer
    async deleteCustomer (customerId) {
        // TODO: Replace with real API call
        // return apiClient.delete(`/customers/${customerId}`)
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mockData$2d$customer$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["delay"])(300);
    }
};
}),
"[project]/hooks/useCustomers.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useCustomers",
    ()=>useCustomers,
    "useDeleteCustomer",
    ()=>useDeleteCustomer,
    "useUpdateCustomerStatus",
    ()=>useUpdateCustomerStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2f$customerService$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/api/customerService.ts [app-rsc] (ecmascript)");
;
;
function useCustomers(filters) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "customers",
            filters
        ],
        queryFn: ()=>__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2f$customerService$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["customerService"].getCustomers(filters)
    });
}
function useUpdateCustomerStatus() {
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: ({ customerId, status })=>__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2f$customerService$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["customerService"].updateCustomerStatus(customerId, status),
        onSuccess: ()=>{
            queryClient.invalidateQueries({
                queryKey: [
                    "customers"
                ]
            });
        }
    });
}
function useDeleteCustomer() {
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: (customerId)=>__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2f$customerService$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["customerService"].deleteCustomer(customerId),
        onSuccess: ()=>{
            queryClient.invalidateQueries({
                queryKey: [
                    "customers"
                ]
            });
        }
    });
}
}),
"[project]/app/fepweb/entities-sync/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EntitiesSyncPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$card$2f$card$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/card/card.esm.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$datatable$2f$datatable$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/datatable/datatable.esm.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/column/column.esm.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$inputtext$2f$inputtext$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/inputtext/inputtext.esm.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$dropdown$2f$dropdown$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/dropdown/dropdown.esm.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$button$2f$button$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/button/button.esm.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$tag$2f$tag$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/tag/tag.esm.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$paginator$2f$paginator$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/primereact/paginator/paginator.esm.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useCustomers$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useCustomers.ts [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
function EntitiesSyncPage() {
    const [search, setSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])("");
    const [statusFilter, setStatusFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])("all");
    const [first, setFirst] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])(0);
    const [rows, setRows] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])(10);
    const { data, isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useCustomers$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useCustomers"])({
        search,
        status: statusFilter
    });
    const updateStatusMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useCustomers$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useUpdateCustomerStatus"])();
    const statusOptions = [
        {
            label: "Todos Status",
            value: "all"
        },
        {
            label: "Ativos",
            value: "Ativo"
        },
        {
            label: "Inativos",
            value: "Inativo"
        }
    ];
    const handleStatusChange = (customerId, currentStatus)=>{
        const newStatus = currentStatus === "Ativo" ? "Inativo" : "Ativo";
        updateStatusMutation.mutate({
            customerId,
            status: newStatus
        });
    };
    const nameBodyTemplate = (customer)=>{
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex align-items-center gap-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex align-items-center justify-content-center border-round",
                    style: {
                        width: "35px",
                        height: "35px",
                        backgroundColor: "#f4f6f9",
                        fontWeight: "bold",
                        color: "#6c757d"
                    },
                    children: customer.avatar
                }, void 0, false, {
                    fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                    lineNumber: 41,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "font-semibold",
                            children: customer.name
                        }, void 0, false, {
                            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                            lineNumber: 54,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                            className: "text-600",
                            children: customer.email
                        }, void 0, false, {
                            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                    lineNumber: 53,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
            lineNumber: 40,
            columnNumber: 7
        }, this);
    };
    const eciBodyTemplate = (customer)=>{
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "font-mono text-sm",
            children: customer.eci
        }, void 0, false, {
            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
            lineNumber: 62,
            columnNumber: 12
        }, this);
    };
    const dateBodyTemplate = (date)=>{
        return new Date(date).toLocaleDateString("pt-BR");
    };
    const statusBodyTemplate = (customer)=>{
        const severity = customer.status === "Ativo" ? "success" : "danger";
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$tag$2f$tag$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Tag"], {
            value: customer.status,
            severity: severity,
            rounded: true
        }, void 0, false, {
            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
            lineNumber: 71,
            columnNumber: 12
        }, this);
    };
    const situationBodyTemplate = (customer)=>{
        const getSituationConfig = (situation)=>{
            switch(situation){
                case "Regular":
                    return {
                        severity: "info",
                        icon: "pi-info-circle"
                    };
                case "Bloqueado":
                    return {
                        severity: "warning",
                        icon: "pi-exclamation-triangle"
                    };
                case "Em Análise":
                    return {
                        severity: null,
                        icon: "pi-clock"
                    };
                default:
                    return {
                        severity: null,
                        icon: "pi-question"
                    };
            }
        };
        const config = getSituationConfig(customer.situation);
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$tag$2f$tag$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Tag"], {
            value: customer.situation,
            severity: config.severity,
            icon: `pi ${config.icon}`,
            style: !config.severity ? {
                backgroundColor: "rgba(108, 117, 125, 0.1)",
                color: "#6c757d",
                border: "1px solid #6c757d"
            } : undefined
        }, void 0, false, {
            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
            lineNumber: 93,
            columnNumber: 7
        }, this);
    };
    const actionsBodyTemplate = (customer)=>{
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex gap-2 justify-content-end",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$button$2f$button$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Button"], {
                    icon: "pi pi-pencil",
                    rounded: true,
                    text: true,
                    severity: "secondary",
                    tooltip: "Editar",
                    tooltipOptions: {
                        position: "top"
                    }
                }, void 0, false, {
                    fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                    lineNumber: 113,
                    columnNumber: 9
                }, this),
                customer.status === "Ativo" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$button$2f$button$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Button"], {
                    icon: "pi pi-ban",
                    rounded: true,
                    text: true,
                    severity: "danger",
                    tooltip: "Desativar",
                    tooltipOptions: {
                        position: "top"
                    },
                    onClick: ()=>handleStatusChange(customer.id, customer.status)
                }, void 0, false, {
                    fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                    lineNumber: 122,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$button$2f$button$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Button"], {
                    icon: "pi pi-check",
                    rounded: true,
                    text: true,
                    severity: "success",
                    tooltip: "Reativar",
                    tooltipOptions: {
                        position: "top"
                    },
                    onClick: ()=>handleStatusChange(customer.id, customer.status)
                }, void 0, false, {
                    fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                    lineNumber: 132,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
            lineNumber: 112,
            columnNumber: 7
        }, this);
    };
    const onPageChange = (event)=>{
        setFirst(event.first);
        setRows(event.rows);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "main-content",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-content-between align-items-center mb-4 pb-2 border-bottom-1 border-200",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                            className: "m-0 text-600",
                            children: "Dashboard de Clientes"
                        }, void 0, false, {
                            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                            lineNumber: 156,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                            className: "text-500",
                            children: "Visão geral da base de clientes (Últimos 30 dias)"
                        }, void 0, false, {
                            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                            lineNumber: 157,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                    lineNumber: 155,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                lineNumber: 154,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "col-12 md:col-6 lg:col-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$card$2f$card$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Card"], {
                            className: "kpi-card shadow-1",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex align-items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "icon-box flex align-items-center justify-content-center border-round mr-3",
                                        style: {
                                            width: "50px",
                                            height: "50px",
                                            backgroundColor: "#e3f2fd",
                                            color: "#0d6efd"
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                            className: "pi pi-user-plus",
                                            style: {
                                                fontSize: "1.5rem"
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                            lineNumber: 177,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                        lineNumber: 168,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h6", {
                                                className: "text-600 mb-1 text-sm",
                                                children: "Novos Cadastros"
                                            }, void 0, false, {
                                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                                lineNumber: 183,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "m-0 mb-1",
                                                children: data?.kpis.newRegistrations.count || 0
                                            }, void 0, false, {
                                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                                lineNumber: 184,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                className: "text-green-500",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                        className: "pi pi-arrow-up"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                                        lineNumber: 188,
                                                        columnNumber: 19
                                                    }, this),
                                                    " ",
                                                    data?.kpis.newRegistrations.percentageChange || 0,
                                                    "% vs mês ant."
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                                lineNumber: 187,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                        lineNumber: 182,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                lineNumber: 167,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                            lineNumber: 166,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                        lineNumber: 165,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "col-12 md:col-6 lg:col-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$card$2f$card$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Card"], {
                            className: "kpi-card shadow-1",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex align-items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "icon-box flex align-items-center justify-content-center border-round mr-3",
                                        style: {
                                            width: "50px",
                                            height: "50px",
                                            backgroundColor: "#fff3cd",
                                            color: "#ffc107"
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                            className: "pi pi-user-edit",
                                            style: {
                                                fontSize: "1.5rem"
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                            lineNumber: 209,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                        lineNumber: 200,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h6", {
                                                className: "text-600 mb-1 text-sm",
                                                children: "Atualizações"
                                            }, void 0, false, {
                                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                                lineNumber: 215,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "m-0 mb-1",
                                                children: data?.kpis.updates.count || 0
                                            }, void 0, false, {
                                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                                lineNumber: 216,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                className: "text-500",
                                                children: "Dados cadastrais"
                                            }, void 0, false, {
                                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                                lineNumber: 217,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                        lineNumber: 214,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                lineNumber: 199,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                            lineNumber: 198,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                        lineNumber: 197,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "col-12 md:col-6 lg:col-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$card$2f$card$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Card"], {
                            className: "kpi-card shadow-1",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex align-items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "icon-box flex align-items-center justify-content-center border-round mr-3",
                                        style: {
                                            width: "50px",
                                            height: "50px",
                                            backgroundColor: "#f8d7da",
                                            color: "#dc3545"
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                            className: "pi pi-user-minus",
                                            style: {
                                                fontSize: "1.5rem"
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                            lineNumber: 235,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                        lineNumber: 226,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h6", {
                                                className: "text-600 mb-1 text-sm",
                                                children: "Desativações"
                                            }, void 0, false, {
                                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                                lineNumber: 241,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "m-0 mb-1",
                                                children: data?.kpis.deactivations.count || 0
                                            }, void 0, false, {
                                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                                lineNumber: 242,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                className: "text-red-500",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                        className: "pi pi-arrow-up"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                                        lineNumber: 246,
                                                        columnNumber: 19
                                                    }, this),
                                                    " Atenção"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                                lineNumber: 245,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                        lineNumber: 240,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                lineNumber: 225,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                            lineNumber: 224,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                        lineNumber: 223,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "col-12 md:col-6 lg:col-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$card$2f$card$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Card"], {
                            className: "kpi-card shadow-1",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex align-items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "icon-box flex align-items-center justify-content-center border-round mr-3",
                                        style: {
                                            width: "50px",
                                            height: "50px",
                                            backgroundColor: "#d1e7dd",
                                            color: "#198754"
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                            className: "pi pi-user-plus",
                                            style: {
                                                fontSize: "1.5rem"
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                            lineNumber: 265,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                        lineNumber: 256,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h6", {
                                                className: "text-600 mb-1 text-sm",
                                                children: "Reativações"
                                            }, void 0, false, {
                                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                                lineNumber: 271,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "m-0 mb-1",
                                                children: data?.kpis.reactivations.count || 0
                                            }, void 0, false, {
                                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                                lineNumber: 272,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                className: "text-green-500",
                                                children: "Recuperados"
                                            }, void 0, false, {
                                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                                lineNumber: 275,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                        lineNumber: 270,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                lineNumber: 255,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                            lineNumber: 254,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                        lineNumber: 253,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                lineNumber: 164,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$card$2f$card$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Card"], {
                className: "shadow-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-content-between align-items-center mb-3 flex-wrap gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                className: "m-0",
                                children: "Base de Clientes"
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                lineNumber: 285,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2 flex-wrap",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "p-input-icon-left",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                className: "pi pi-search"
                                            }, void 0, false, {
                                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                                lineNumber: 288,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$inputtext$2f$inputtext$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["InputText"], {
                                                placeholder: "Buscar por Nome ou CNPJ...",
                                                value: search,
                                                onChange: (e)=>setSearch(e.target.value),
                                                className: "w-full md:w-20rem"
                                            }, void 0, false, {
                                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                                lineNumber: 289,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                        lineNumber: 287,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$dropdown$2f$dropdown$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Dropdown"], {
                                        value: statusFilter,
                                        options: statusOptions,
                                        onChange: (e)=>setStatusFilter(e.value),
                                        placeholder: "Todos Status",
                                        className: "w-full md:w-10rem"
                                    }, void 0, false, {
                                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                        lineNumber: 296,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                lineNumber: 286,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                        lineNumber: 284,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$datatable$2f$datatable$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["DataTable"], {
                        value: data?.customers || [],
                        loading: isLoading,
                        stripedRows: true,
                        showGridlines: false,
                        emptyMessage: "Nenhum cliente encontrado",
                        className: "customer-table",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Column"], {
                                field: "name",
                                header: "Nome / Razão Social",
                                body: nameBodyTemplate,
                                style: {
                                    minWidth: "250px"
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                lineNumber: 314,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Column"], {
                                field: "eci",
                                header: "ECI",
                                body: eciBodyTemplate,
                                style: {
                                    minWidth: "120px"
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                lineNumber: 320,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Column"], {
                                field: "cnpjCpf",
                                header: "CNPJ / CPF",
                                style: {
                                    minWidth: "150px"
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                lineNumber: 326,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Column"], {
                                field: "createdAt",
                                header: "Data Criação",
                                body: (rowData)=>dateBodyTemplate(rowData.createdAt),
                                style: {
                                    minWidth: "130px"
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                lineNumber: 331,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Column"], {
                                field: "updatedAt",
                                header: "Data Atualização",
                                body: (rowData)=>dateBodyTemplate(rowData.updatedAt),
                                style: {
                                    minWidth: "150px"
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                lineNumber: 337,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Column"], {
                                field: "status",
                                header: "Status",
                                body: statusBodyTemplate,
                                style: {
                                    minWidth: "100px"
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                lineNumber: 343,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Column"], {
                                field: "situation",
                                header: "Situação",
                                body: situationBodyTemplate,
                                style: {
                                    minWidth: "130px"
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                lineNumber: 349,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Column"], {
                                header: "Ações",
                                body: actionsBodyTemplate,
                                style: {
                                    minWidth: "120px",
                                    textAlign: "right"
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                                lineNumber: 355,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                        lineNumber: 306,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$paginator$2f$paginator$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Paginator"], {
                        first: first,
                        rows: rows,
                        totalRecords: data?.totalRecords || 0,
                        rowsPerPageOptions: [
                            5,
                            10,
                            20,
                            50
                        ],
                        onPageChange: onPageChange,
                        className: "mt-3"
                    }, void 0, false, {
                        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                        lineNumber: 362,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/fepweb/entities-sync/page.tsx",
                lineNumber: 283,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/fepweb/entities-sync/page.tsx",
        lineNumber: 152,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/fepweb/entities-sync/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/fepweb/entities-sync/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__fff1bc3a._.js.map