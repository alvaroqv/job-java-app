module.exports = [
"[project]/.next-internal/server/app/fepweb/fx-agreement/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_fepweb_fx-agreement_page_actions_20c3c4d6.js.map