"use client"

import { useState } from "react"
import { Card } from "primereact/card"
import { DataTable } from "primereact/datatable"
import { Column } from "primereact/column"
import { InputText } from "primereact/inputtext"
import { Dropdown } from "primereact/dropdown"
import { Calendar } from "primereact/calendar"
import { Button } from "primereact/button"
import { Tag } from "primereact/tag"
import { Chip } from "primereact/chip"
import { Menu } from "primereact/menu"
import { useContracts } from "@/hooks/useContracts"
import type { ContractFilters, Contract } from "@/types/contract"
import "./fx-agreement.css"

export default function FxAgreementPage() {
  const [filters, setFilters] = useState<ContractFilters>({
    status: "Assinado",
    startDate: "2025-01-01",
    endDate: "2025-01-31",
  })

  const { stats, contracts, total, filtered, isLoading } = useContracts(filters)

  const statusOptions = [
    { label: "Todos", value: "" },
    { label: "Assinados", value: "Assinado" },
    { label: "Pendentes", value: "Pendente" },
    { label: "Novos", value: "Novo" },
  ]

  const handleFilterChange = (key: keyof ContractFilters, value: any) => {
    setFilters((prev) => ({ ...prev, [key]: value }))
  }

  const handleRemoveFilter = (key: keyof ContractFilters) => {
    setFilters((prev) => {
      const newFilters = { ...prev }
      delete newFilters[key]
      return newFilters
    })
  }

  const clearAllFilters = () => {
    setFilters({})
  }

  const exportMenuItems = [
    {
      label: "Excel (.xls)",
      icon: "pi pi-file-excel",
      command: () => console.log("Export to Excel"),
    },
    {
      label: "PDF",
      icon: "pi pi-file-pdf",
      command: () => console.log("Export to PDF"),
    },
  ]

  const statusBodyTemplate = (rowData: Contract) => {
    const statusConfig = {
      Assinado: { severity: "success" as const, icon: "pi pi-check" },
      Pendente: { severity: "warning" as const, icon: "pi pi-clock" },
      Novo: { severity: "info" as const, icon: "pi pi-file" },
    }
    const config = statusConfig[rowData.status]
    return <Tag value={rowData.status} severity={config.severity} icon={config.icon} className="status-badge" />
  }

  const clientBodyTemplate = (rowData: Contract) => {
    return (
      <div>
        <div className="fw-bold">{rowData.clientName}</div>
        <small className="text-muted">{rowData.contractCode}</small>
      </div>
    )
  }

  const eciBodyTemplate = (rowData: Contract) => {
    return <span className="eci-code">{rowData.eci}</span>
  }

  const callbackBodyTemplate = (rowData: Contract) => {
    if (!rowData.callbackDate) {
      return <span className="text-muted">-</span>
    }
    return (
      <div className="callback-date">
        <i className="pi pi-clock me-1"></i>
        {new Date(rowData.callbackDate).toLocaleDateString("pt-BR")}
      </div>
    )
  }

  const actionsBodyTemplate = (rowData: Contract) => {
    return (
      <div className="text-end">
        {rowData.pdfUrl && (
          <Button
            icon="pi pi-file-pdf"
            className="p-button-text p-button-danger"
            tooltip="Visualizar PDF"
            tooltipOptions={{ position: "top" }}
          />
        )}
      </div>
    )
  }

  const formatDate = (dateString?: string) => {
    if (!dateString) return "-"
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  const activeFilters = []
  if (filters.status) {
    activeFilters.push({ key: "status", label: `Status: ${filters.status}` })
  }
  if (filters.startDate && filters.endDate) {
    activeFilters.push({
      key: "dates",
      label: `Período: ${formatDate(filters.startDate)} - ${formatDate(filters.endDate)}`,
    })
  }

  return (
    <div className="fx-agreement-page">
      <div className="page-header">
        <div>
          <h4 className="page-title">Gestão de Contratos</h4>
          <p className="page-subtitle">Acompanhamento de assinaturas e status</p>
        </div>
        <div className="header-actions">
          <Button label="Novo Contrato" icon="pi pi-plus" />
          <Button
            label="Exportar"
            icon="pi pi-download"
            className="p-button-outlined"
            onClick={(e) => {
              const menu = document.querySelector(".export-menu") as any
              menu?.toggle(e)
            }}
          />
          <Menu model={exportMenuItems} popup className="export-menu" />
        </div>
      </div>

      <div className="kpi-cards">
        <Card className="kpi-card border-info">
          <div className="kpi-content">
            <div className="icon-box bg-info">
              <i className="pi pi-file"></i>
            </div>
            <div>
              <h6 className="kpi-label">Novos Contratos</h6>
              <h3 className="kpi-value">{stats?.newContracts || 0}</h3>
            </div>
          </div>
        </Card>

        <Card className="kpi-card border-warning">
          <div className="kpi-content">
            <div className="icon-box bg-warning">
              <i className="pi pi-pencil"></i>
            </div>
            <div>
              <h6 className="kpi-label">Pendentes de Assinatura</h6>
              <h3 className="kpi-value">{stats?.pendingSignature || 0}</h3>
            </div>
          </div>
        </Card>

        <Card className="kpi-card border-success">
          <div className="icon-box bg-success">
            <i className="pi pi-check-circle"></i>
          </div>
          <div>
            <h6 className="kpi-label">Contratos Assinados</h6>
            <h3 className="kpi-value">{stats?.signed || 0}</h3>
          </div>
        </Card>
      </div>

      <Card className="filters-card">
        <div className="filters-grid">
          <div className="filter-field">
            <label className="filter-label">Busca Geral</label>
            <InputText
              placeholder="Nome ou ECI..."
              value={filters.search || ""}
              onChange={(e) => handleFilterChange("search", e.target.value)}
            />
          </div>

          <div className="filter-field">
            <label className="filter-label">Documento</label>
            <InputText
              placeholder="CNPJ / CPF"
              value={filters.document || ""}
              onChange={(e) => handleFilterChange("document", e.target.value)}
            />
          </div>

          <div className="filter-field">
            <label className="filter-label">Status</label>
            <Dropdown
              value={filters.status}
              options={statusOptions}
              onChange={(e) => handleFilterChange("status", e.value)}
              placeholder="Todos"
            />
          </div>

          <div className="filter-field">
            <label className="filter-label">Data Início</label>
            <Calendar
              value={filters.startDate ? new Date(filters.startDate) : null}
              onChange={(e) => handleFilterChange("startDate", e.value?.toISOString().split("T")[0])}
              dateFormat="dd/mm/yy"
            />
          </div>

          <div className="filter-field">
            <label className="filter-label">Data Fim</label>
            <Calendar
              value={filters.endDate ? new Date(filters.endDate) : null}
              onChange={(e) => handleFilterChange("endDate", e.value?.toISOString().split("T")[0])}
              dateFormat="dd/mm/yy"
            />
          </div>

          <div className="filter-field filter-button">
            <label className="filter-label">&nbsp;</label>
            <Button label="Filtrar" icon="pi pi-filter" />
          </div>
        </div>
      </Card>

      {activeFilters.length > 0 && (
        <div className="active-filters">
          <span className="active-filters-label">
            <i className="pi pi-filter"></i> Filtros Ativos:
          </span>
          {activeFilters.map((filter) => (
            <Chip
              key={filter.key}
              label={filter.label}
              removable
              onRemove={() => {
                if (filter.key === "dates") {
                  handleRemoveFilter("startDate")
                  handleRemoveFilter("endDate")
                } else {
                  handleRemoveFilter(filter.key as keyof ContractFilters)
                }
              }}
              className="active-filter-chip"
            />
          ))}
          <Button label="Limpar tudo" className="p-button-text p-button-danger p-button-sm" onClick={clearAllFilters} />
        </div>
      )}

      <Card className="table-card">
        <DataTable
          value={contracts}
          loading={isLoading}
          paginator
          rows={10}
          className="contracts-table"
          emptyMessage="Nenhum contrato encontrado"
        >
          <Column field="clientName" header="Nome do Cliente" body={clientBodyTemplate} />
          <Column field="eci" header="ECI" body={eciBodyTemplate} />
          <Column field="document" header="CNPJ / CPF" />
          <Column field="status" header="Situação" body={statusBodyTemplate} />
          <Column field="contractDate" header="Data Contrato" body={(data) => formatDate(data.contractDate)} />
          <Column field="signatureDate" header="Data Assinatura" body={(data) => formatDate(data.signatureDate)} />
          <Column field="callbackDate" header="Data CallBack" body={callbackBodyTemplate} />
          <Column header="Ações" body={actionsBodyTemplate} className="text-end" />
        </DataTable>

        <div className="table-footer">
          <small className="text-muted">
            Mostrando {filtered} resultados {filtered !== total && `(filtrado de ${total})`}
          </small>
        </div>
      </Card>
    </div>
  )
}
