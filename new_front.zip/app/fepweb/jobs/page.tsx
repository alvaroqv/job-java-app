"use client";

import { useState } from "react";
import { Card } from "primereact/card";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Button } from "primereact/button";
import { Badge } from "primereact/badge";
import { Dialog } from "primereact/dialog";
import { InputText } from "primereact/inputtext";
import { Dropdown } from "primereact/dropdown";
import { InputTextarea } from "primereact/inputtextarea";
import { RadioButton } from "primereact/radiobutton";
import { InputSwitch } from "primereact/inputswitch";
import { Steps } from "primereact/steps";
import {
  useEntitiesSyncStats,
  useJobExecutions,
  useJobs,
  useReports,
  useDatabaseConnections,
  useDeleteJob,
  useRunJob,
} from "@/hooks/useJobsSync";
import type { JobExecution } from "@/types/jobs-sync";

export default function EntitiesSyncPage() {
  const [activeView, setActiveView] = useState<
    "dashboard" | "jobs" | "history" | "connections"
  >("dashboard");
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showRunModal, setShowRunModal] = useState(false);
  const [showWizard, setShowWizard] = useState(false);
  const [wizardMode, setWizardMode] = useState<"new" | "edit">("new");
  const [activeStep, setActiveStep] = useState(0);
  const [filterStatus, setFilterStatus] = useState<string | null>(null);
  const [showConnectionModal, setShowConnectionModal] = useState(false);

  // Wizard form state
  const [jobName, setJobName] = useState("");
  const [jobArea, setJobArea] = useState("Financeiro");
  const [jobType, setJobType] = useState<"sql" | "python">("sql");
  const [scheduleEnabled, setScheduleEnabled] = useState(true);
  const [selectedDays, setSelectedDays] = useState({
    seg: true,
    ter: true,
    qua: true,
    qui: true,
    sex: true,
    sab: false,
    dom: false,
  });

  // React Query hooks
  const { data: stats } = useEntitiesSyncStats();
  const { data: executions } = useJobExecutions();
  const { data: jobs } = useJobs();
  const { data: reports } = useReports();
  const { data: connections } = useDatabaseConnections();
  const deleteJobMutation = useDeleteJob();
  const runJobMutation = useRunJob();

  const steps = [
    { label: "Dados Básicos" },
    { label: "Configuração" },
    { label: "Agendamento" },
  ];

  const filteredExecutions = filterStatus
    ? executions?.filter((e) => e.status === filterStatus)
    : executions;

  const statusBodyTemplate = (rowData: JobExecution) => {
    const severityMap = {
      success: "success",
      error: "danger",
      running: "info",
    } as const;

    const labelMap = {
      success: "Sucesso",
      error: "Erro",
      running: "Running",
    };

    return (
      <Badge
        value={labelMap[rowData.status]}
        severity={severityMap[rowData.status]}
      />
    );
  };

  const actionsBodyTemplate = (rowData: JobExecution) => {
    return (
      <div className="flex gap-2 justify-end">
        <Button
          icon="pi pi-file"
          rounded
          outlined
          size="small"
          severity="secondary"
          tooltip="Ver Log"
        />
      </div>
    );
  };

  const jobActionsTemplate = () => {
    return (
      <div className="flex gap-2 justify-end">
        <Button
          icon="pi pi-play"
          rounded
          size="small"
          severity="success"
          tooltip="Executar Agora"
          onClick={() => setShowRunModal(true)}
        />
        <Button
          icon="pi pi-pencil"
          rounded
          outlined
          size="small"
          tooltip="Editar Job"
          onClick={() => {
            setWizardMode("edit");
            setShowWizard(true);
            setActiveView("dashboard");
          }}
        />
        <Button
          icon="pi pi-trash"
          rounded
          outlined
          size="small"
          severity="danger"
          tooltip="Excluir Job"
          onClick={() => setShowDeleteModal(true)}
        />
      </div>
    );
  };

  const reportActionsTemplate = () => {
    return (
      <div className="flex gap-2 justify-end">
        <Button label="CSV" icon="pi pi-download" size="small" />
      </div>
    );
  };

  const connectionActionsTemplate = () => {
    return (
      <div className="flex gap-2 justify-end">
        <Button
          icon="pi pi-pencil"
          rounded
          outlined
          size="small"
          tooltip="Editar"
          onClick={() => setShowConnectionModal(true)}
        />
      </div>
    );
  };

  const handleNextStep = () => {
    if (activeStep < 2) {
      setActiveStep(activeStep + 1);
    } else {
      // Save job
      setShowWizard(false);
      setActiveStep(0);
      setActiveView("jobs");
    }
  };

  const handlePrevStep = () => {
    if (activeStep > 0) {
      setActiveStep(activeStep - 1);
    }
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6 pb-4 border-b border-gray-200">
        <h4 className="text-2xl font-semibold text-gray-600">
          {activeView === "dashboard" && "Visão Geral"}
          {activeView === "jobs" && "Gerenciar Tarefas"}
          {activeView === "history" && "Relatórios Disponíveis"}
          {activeView === "connections" && "Conexões de Banco de Dados"}
        </h4>
        <div className="flex gap-3">
          <Button
            label="Dashboard"
            icon="pi pi-chart-bar"
            outlined={activeView !== "dashboard"}
            onClick={() => setActiveView("dashboard")}
            size="small"
          />
          <Button
            label="Jobs"
            icon="pi pi-cog"
            outlined={activeView !== "jobs"}
            onClick={() => setActiveView("jobs")}
            size="small"
          />
          <Button
            label="Histórico"
            icon="pi pi-history"
            outlined={activeView !== "history"}
            onClick={() => setActiveView("history")}
            size="small"
          />
          <Button
            label="Conexões"
            icon="pi pi-database"
            outlined={activeView !== "connections"}
            onClick={() => setActiveView("connections")}
            size="small"
          />
        </div>
      </div>

      {/* Dashboard View */}
      {activeView === "dashboard" && !showWizard && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card
              className="cursor-pointer hover:shadow-lg transition-all border-l-4 border-blue-500"
              onClick={() => setFilterStatus("running")}
            >
              <h6 className="text-gray-500 mb-2">Em Execução</h6>
              <h3 className="text-3xl font-bold">
                {stats?.running.toString().padStart(2, "0")}
              </h3>
            </Card>
            <Card
              className="cursor-pointer hover:shadow-lg transition-all border-l-4 border-green-500"
              onClick={() => setFilterStatus("success")}
            >
              <h6 className="text-gray-500 mb-2">Sucesso (24h)</h6>
              <h3 className="text-3xl font-bold">{stats?.success24h}</h3>
            </Card>
            <Card
              className="cursor-pointer hover:shadow-lg transition-all border-l-4 border-red-500"
              onClick={() => setFilterStatus("error")}
            >
              <h6 className="text-gray-500 mb-2">Falhas (24h)</h6>
              <h3 className="text-3xl font-bold">
                {stats?.errors24h.toString().padStart(2, "0")}
              </h3>
            </Card>
            <Card
              className="cursor-pointer hover:shadow-lg transition-all border-l-4 border-cyan-500"
              onClick={() => setFilterStatus(null)}
            >
              <h6 className="text-gray-500 mb-2">Todos Jobs</h6>
              <h3 className="text-xl font-bold">Ver Tudo</h3>
            </Card>
          </div>

          <Card title="Execuções Recentes">
            <DataTable value={filteredExecutions} stripedRows>
              <Column
                field="status"
                header="Status"
                body={statusBodyTemplate}
              />
              <Column field="jobName" header="Nome do Job" />
              <Column field="area" header="Área" />
              <Column field="startTime" header="Início" />
              <Column header="Ações" body={actionsBodyTemplate} />
            </DataTable>
          </Card>
        </>
      )}

      {/* Jobs View */}
      {activeView === "jobs" && !showWizard && (
        <>
          <div className="flex justify-end mb-4">
            <Button
              label="Novo Job"
              icon="pi pi-plus"
              onClick={() => {
                setWizardMode("new");
                setShowWizard(true);
                setActiveView("dashboard");
              }}
            />
          </div>
          <Card>
            <DataTable value={jobs} stripedRows>
              <Column field="name" header="Nome" />
              <Column
                field="type"
                header="Tipo"
                body={(rowData) => (
                  <Badge
                    value={rowData.type}
                    severity={rowData.type === "SQL" ? "info" : "warning"}
                  />
                )}
              />
              <Column field="cron" header="CRON" />
              <Column header="Ações" body={jobActionsTemplate} />
            </DataTable>
          </Card>
        </>
      )}

      {/* Wizard View */}
      {showWizard && (
        <Card
          title={wizardMode === "new" ? "Criar Novo Job" : "Editar Job"}
          subTitle={
            <Button
              label="Cancelar"
              outlined
              size="small"
              onClick={() => {
                setShowWizard(false);
                setActiveStep(0);
                setActiveView("jobs");
              }}
            />
          }
        >
          <Steps model={steps} activeIndex={activeStep} className="mb-6" />

          {/* Step 1: Basic Data */}
          {activeStep === 0 && (
            <div className="space-y-4">
              <h6 className="text-center mb-6 text-lg font-semibold">
                Dados Básicos
              </h6>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col gap-2">
                  <label>Nome do Job</label>
                  <InputText
                    value={jobName}
                    onChange={(e) => setJobName(e.target.value)}
                  />
                </div>
                <div className="flex flex-col gap-2">
                  <label>Área</label>
                  <Dropdown
                    value={jobArea}
                    options={["Financeiro", "TI", "Comercial", "Logística"]}
                    onChange={(e) => setJobArea(e.value)}
                  />
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <label>Tipo de Job</label>
                <div className="flex gap-4">
                  <div className="flex items-center gap-2">
                    <RadioButton
                      inputId="typeSQL"
                      value="sql"
                      onChange={(e) => setJobType(e.value)}
                      checked={jobType === "sql"}
                    />
                    <label htmlFor="typeSQL">Query SQL</label>
                  </div>
                  <div className="flex items-center gap-2">
                    <RadioButton
                      inputId="typePython"
                      value="python"
                      onChange={(e) => setJobType(e.value)}
                      checked={jobType === "python"}
                    />
                    <label htmlFor="typePython">Script Python</label>
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <label className="font-semibold">Parâmetros de Entrada</label>
                <Card className="mt-2 bg-gray-50">
                  <DataTable
                    value={[
                      { name: "data_ref", type: "Data", defaultValue: "" },
                    ]}
                  >
                    <Column field="name" header="Nome Param" />
                    <Column field="type" header="Tipo" />
                    <Column field="defaultValue" header="Valor Padrão" />
                    <Column
                      header="Ação"
                      body={() => (
                        <Button
                          icon="pi pi-times"
                          rounded
                          text
                          severity="danger"
                          size="small"
                        />
                      )}
                    />
                  </DataTable>
                  <Button
                    label="+ Adicionar Parâmetro"
                    link
                    className="mt-2"
                    size="small"
                  />
                </Card>
              </div>
            </div>
          )}

          {/* Step 2: Configuration */}
          {activeStep === 1 && (
            <div className="space-y-4">
              <h6 className="text-center mb-6 text-lg font-semibold">
                {jobType === "sql"
                  ? "Configurar Query SQL"
                  : "Configurar Script Python"}
              </h6>

              {jobType === "sql" ? (
                <>
                  <div className="flex flex-col gap-2">
                    <label>Conexão</label>
                    <Dropdown
                      value="Oracle Prod"
                      options={["Oracle Prod", "PostgreSQL Dev"]}
                      className="w-1/2"
                    />
                  </div>
                  <div className="flex flex-col gap-2">
                    <label>Query</label>
                    <InputTextarea
                      value="SELECT * FROM tabela WHERE dt = :data_ref"
                      rows={6}
                      className="font-mono bg-gray-900 text-gray-100"
                    />
                  </div>
                  <Button
                    label="Validar & Mapear Colunas"
                    icon="pi pi-sync"
                    outlined
                    size="small"
                  />
                </>
              ) : (
                <div className="flex flex-col gap-2">
                  <label>Script Python</label>
                  <Dropdown
                    value="etl_mensal.py"
                    options={["etl_mensal.py", "sync_data.py"]}
                  />
                </div>
              )}
            </div>
          )}

          {/* Step 3: Schedule */}
          {activeStep === 2 && (
            <div className="space-y-4">
              <h6 className="text-center mb-6 text-lg font-semibold">
                Agendamento & Notificações
              </h6>

              <Card className="bg-gray-50">
                <div className="flex items-center gap-3">
                  <InputSwitch
                    checked={scheduleEnabled}
                    onChange={(e) => setScheduleEnabled(e.value)}
                  />
                  <label className="font-semibold">
                    Execução Automática (Agendada)
                  </label>
                </div>
              </Card>

              {scheduleEnabled && (
                <div className="space-y-4">
                  <div className="flex flex-col gap-2">
                    <label>Dias da Execução:</label>
                    <div className="flex gap-2">
                      {Object.entries(selectedDays).map(([day, checked]) => (
                        <Button
                          key={day}
                          label={day.charAt(0).toUpperCase() + day.slice(1)}
                          outlined={!checked}
                          size="small"
                          onClick={() =>
                            setSelectedDays((prev) => ({
                              ...prev,
                              [day]: !prev[day as keyof typeof prev],
                            }))
                          }
                        />
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col gap-2">
                      <label>Horário de Início:</label>
                      <InputText type="time" defaultValue="08:00" />
                    </div>
                    <div className="flex flex-col gap-2">
                      <label>Intervalo de Repetição:</label>
                      <Dropdown
                        defaultValue="once"
                        options={[
                          { label: "Executar uma vez por dia", value: "once" },
                          { label: "Repetir a cada 1 hora", value: "1h" },
                          { label: "Repetir a cada 6 horas", value: "6h" },
                          { label: "Repetir a cada 12 horas", value: "12h" },
                        ]}
                      />
                    </div>
                  </div>
                </div>
              )}

              <div className="flex flex-col gap-2 mt-6">
                <label>Notificar por E-mail (Separar por vírgula):</label>
                <InputText placeholder="gestor@empresa.com" />
              </div>
            </div>
          )}

          {/* Wizard Navigation */}
          <div className="flex justify-between mt-6 pt-4 border-t">
            <Button
              label="Voltar"
              outlined
              onClick={handlePrevStep}
              disabled={activeStep === 0}
            />
            <Button
              label={activeStep === 2 ? "Salvar" : "Próximo"}
              onClick={handleNextStep}
            />
          </div>
        </Card>
      )}

      {/* History View */}
      {activeView === "history" && (
        <Card>
          <DataTable value={reports} stripedRows>
            <Column field="jobName" header="Job" />
            <Column field="generationDate" header="Data Geração" />
            <Column field="size" header="Tamanho" />
            <Column header="Download" body={reportActionsTemplate} />
          </DataTable>
        </Card>
      )}

      {/* Connections View */}
      {activeView === "connections" && (
        <>
          <div className="flex justify-end mb-4">
            <Button
              label="Nova Conexão"
              icon="pi pi-plus"
              onClick={() => setShowConnectionModal(true)}
            />
          </div>
          <Card>
            <DataTable value={connections} stripedRows>
              <Column field="name" header="Nome" />
              <Column field="driver" header="Driver" />
              <Column field="host" header="Host" />
              <Column field="database" header="Banco" />
              <Column header="Ações" body={connectionActionsTemplate} />
            </DataTable>
          </Card>
        </>
      )}

      {/* Delete Modal */}
      <Dialog
        header="Confirmar Exclusão"
        visible={showDeleteModal}
        style={{ width: "30vw" }}
        onHide={() => setShowDeleteModal(false)}
        footer={
          <div>
            <Button
              label="Cancelar"
              outlined
              onClick={() => setShowDeleteModal(false)}
            />
            <Button
              label="Excluir"
              severity="danger"
              onClick={() => setShowDeleteModal(false)}
            />
          </div>
        }
      >
        <p>Tem certeza que deseja excluir este job?</p>
      </Dialog>

      {/* Run Modal */}
      <Dialog
        header="Executar Job"
        visible={showRunModal}
        style={{ width: "30vw" }}
        onHide={() => setShowRunModal(false)}
        footer={
          <div>
            <Button
              label="Cancelar"
              outlined
              onClick={() => setShowRunModal(false)}
            />
            <Button
              label="Executar"
              severity="success"
              onClick={() => setShowRunModal(false)}
            />
          </div>
        }
      >
        <p>Confirmar execução imediata do job?</p>
      </Dialog>

      {/* Connection Modal */}
      <Dialog
        header="Nova Conexão"
        visible={showConnectionModal}
        style={{ width: "50vw" }}
        onHide={() => setShowConnectionModal(false)}
        footer={
          <div>
            <Button
              label="Cancelar"
              outlined
              onClick={() => setShowConnectionModal(false)}
            />
            <Button
              label="Salvar"
              onClick={() => setShowConnectionModal(false)}
            />
          </div>
        }
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col gap-2">
              <label>Nome da Conexão</label>
              <InputText placeholder="Ex: Produção Oracle" />
            </div>
            <div className="flex flex-col gap-2">
              <label>Driver / Tipo</label>
              <Dropdown
                options={["PostgreSQL", "Oracle DB", "SQL Server", "MySQL"]}
                placeholder="Selecione"
              />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div className="flex flex-col gap-2 col-span-2">
              <label>Host (IP ou URL)</label>
              <InputText placeholder="192.168.0.1" />
            </div>
            <div className="flex flex-col gap-2">
              <label>Porta</label>
              <InputText placeholder="5432" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col gap-2">
              <label>Banco de Dados</label>
              <InputText placeholder="mydb" />
            </div>
            <div className="flex flex-col gap-2">
              <label>Usuário</label>
              <InputText placeholder="admin" />
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <label>Senha</label>
            <InputText type="password" placeholder="••••••••" />
          </div>
        </div>
      </Dialog>
    </div>
  );
}
