"use client";

import { useState } from "react";
import {
  useCustomers,
  useUpdateCustomerStatus,
  useDeleteCustomer,
} from "@/hooks/useCustomers";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText } from "primereact/inputtext";
import { Dropdown } from "primereact/dropdown";
import { Button } from "primereact/button";
import { confirmDialog } from "primereact/confirmdialog";
import { ConfirmDialog } from "primereact/confirmdialog";
import type { Customer, CustomerFilters } from "@/types/customer";
import "./entities-sync.css";

export default function EntitiesSyncPage() {
  const [filters, setFilters] = useState<CustomerFilters>({
    search: "",
    status: "all",
  });

  const { data, isLoading } = useCustomers(filters);
  const updateStatusMutation = useUpdateCustomerStatus();
  const deleteCustomerMutation = useDeleteCustomer();

  const statusOptions = [
    { label: "Todos Status", value: "all" },
    { label: "Ativo", value: "Ativo" },
    { label: "Inativo", value: "Inativo" },
  ];

  const handleSearch = (value: string) => {
    setFilters((prev) => ({ ...prev, search: value }));
  };

  const handleStatusFilter = (value: string) => {
    setFilters((prev) => ({
      ...prev,
      status: value as CustomerFilters["status"],
    }));
  };

  const handleDeleteCustomer = (customerId: string) => {
    confirmDialog({
      message: "Tem certeza que deseja excluir este cliente?",
      header: "Confirmar Exclusão",
      icon: "pi pi-exclamation-triangle",
      accept: () => {
        deleteCustomerMutation.mutate(customerId);
      },
    });
  };

  const avatarBodyTemplate = (rowData: Customer) => {
    return (
      <div className="customer-info">
        <div className="customer-avatar">
          {rowData.avatar || rowData.name.charAt(0)}
        </div>
        <div>
          <div className="customer-name">{rowData.name}</div>
          <div className="customer-email">{rowData.email}</div>
        </div>
      </div>
    );
  };

  const eciBodyTemplate = (rowData: Customer) => {
    return <span className="eci-code">{rowData.eci}</span>;
  };

  const statusBodyTemplate = (rowData: Customer) => {
    return (
      <span className={`status-badge status-${rowData.status.toLowerCase()}`}>
        {rowData.status}
      </span>
    );
  };

  const situationBodyTemplate = (rowData: Customer) => {
    const situationClass = rowData.situation.toLowerCase().replace(" ", "-");
    return (
      <span className={`situation-badge situation-${situationClass}`}>
        {rowData.situation}
      </span>
    );
  };

  const actionsBodyTemplate = (rowData: Customer) => {
    return (
      <div className="action-buttons">
        <Button
          icon="pi pi-pencil"
          rounded
          text
          severity="secondary"
          className="action-btn edit-btn"
          onClick={() => console.log("Edit", rowData.id)}
        />
        <Button
          icon="pi pi-times"
          rounded
          text
          severity="danger"
          className="action-btn delete-btn"
          onClick={() => handleDeleteCustomer(rowData.id)}
        />
      </div>
    );
  };

  return (
    <div className="entities-sync-page">
      <ConfirmDialog />

      <div className="page-header">
        <h1 className="page-title">Dashboard de Clientes</h1>
        <p className="page-subtitle">
          Visão geral da base de clientes (Últimos 30 dias)
        </p>
      </div>

      <div className="kpi-cards">
        <div className="kpi-card kpi-blue">
          <div className="kpi-icon-wrapper kpi-icon-blue">
            <i className="pi pi-user-plus kpi-icon"></i>
          </div>
          <div className="kpi-content">
            <div className="kpi-label">Novos Cadastros</div>
            <div className="kpi-value">
              {data?.kpis.newRegistrations.count || 0}
            </div>
            <div className="kpi-trend kpi-trend-up">
              <i className="pi pi-arrow-up"></i>{" "}
              {data?.kpis.newRegistrations.percentageChange || 0}% vs mês ant.
            </div>
          </div>
        </div>

        <div className="kpi-card kpi-yellow">
          <div className="kpi-icon-wrapper kpi-icon-yellow">
            <i className="pi pi-refresh kpi-icon"></i>
          </div>
          <div className="kpi-content">
            <div className="kpi-label">Atualizações</div>
            <div className="kpi-value">{data?.kpis.updates.count || 0}</div>
            <div className="kpi-description">Dados cadastrais</div>
          </div>
        </div>

        <div className="kpi-card kpi-red">
          <div className="kpi-icon-wrapper kpi-icon-red">
            <i className="pi pi-user-minus kpi-icon"></i>
          </div>
          <div className="kpi-content">
            <div className="kpi-label">Desativações</div>
            <div className="kpi-value">
              {String(data?.kpis.deactivations.count || 0).padStart(2, "0")}
            </div>
            <div className="kpi-alert">
              <i className="pi pi-arrow-up"></i> Atenção
            </div>
          </div>
        </div>

        <div className="kpi-card kpi-green">
          <div className="kpi-icon-wrapper kpi-icon-green">
            <i className="pi pi-check-circle kpi-icon"></i>
          </div>
          <div className="kpi-content">
            <div className="kpi-label">Reativações</div>
            <div className="kpi-value">
              {data?.kpis.reactivations.count || 0}
            </div>
            <div className="kpi-recovered">Recuperados</div>
          </div>
        </div>
      </div>

      <div className="table-section">
        <div className="table-header">
          <h2 className="table-title">Base de Clientes</h2>
          <div className="table-filters">
            <div className="search-input-wrapper">
              <i className="pi pi-search search-icon"></i>
              <InputText
                value={filters.search}
                onChange={(e) => handleSearch(e.target.value)}
                placeholder="Buscar por Nome ou CNPJ..."
                className="search-input"
              />
            </div>
            <Dropdown
              value={filters.status}
              options={statusOptions}
              onChange={(e) => handleStatusFilter(e.value)}
              className="status-dropdown"
            />
          </div>
        </div>

        <DataTable
          value={data?.customers || []}
          loading={isLoading}
          paginator
          rows={10}
          paginatorTemplate="PrevPageLink PageLinks NextPageLink"
          currentPageReportTemplate="{first} to {last} of {totalRecords}"
          className="customers-table"
        >
          <Column
            field="name"
            header="Nome / Razão Social"
            body={avatarBodyTemplate}
            style={{ minWidth: "250px" }}
          />
          <Column
            field="eci"
            header="ECI"
            body={eciBodyTemplate}
            style={{ width: "120px" }}
          />
          <Column
            field="cnpjCpf"
            header="CNPJ / CPF"
            style={{ width: "180px" }}
          />
          <Column
            field="createdAt"
            header="Data Criação"
            style={{ width: "140px" }}
          />
          <Column
            field="updatedAt"
            header="Data Atualização"
            style={{ width: "160px" }}
          />
          <Column
            field="status"
            header="Status"
            body={statusBodyTemplate}
            style={{ width: "120px" }}
          />
          <Column
            field="situation"
            header="Situação"
            body={situationBodyTemplate}
            style={{ width: "140px" }}
          />
          <Column
            header="Ações"
            body={actionsBodyTemplate}
            style={{ width: "100px" }}
          />
        </DataTable>
      </div>
    </div>
  );
}
