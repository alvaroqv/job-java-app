"use client"

import { useState } from "react"
import { Card } from "primereact/card"
import { DataTable } from "primereact/datatable"
import { Column } from "primereact/column"
import { InputText } from "primereact/inputtext"
import { Dropdown } from "primereact/dropdown"
import { Button } from "primereact/button"
import { Dialog } from "primereact/dialog"
import { Badge } from "primereact/badge"
import { useContractIntegration } from "@/hooks/useContractIntegration"
import type { ContractIntegration } from "@/types/contract-integration"
import "./fx-contracts.css"

export default function FxContractsPage() {
  const [filters, setFilters] = useState({
    search: "",
    status: "all" as "all" | "imported" | "not_imported",
  })
  const [selectedContract, setSelectedContract] = useState<ContractIntegration | null>(null)
  const [errorDialogVisible, setErrorDialogVisible] = useState(false)

  const { stats, contracts, isLoading, retryImport } = useContractIntegration(filters)

  const statusOptions = [
    { label: "Status: Todos", value: "all" },
    { label: "Erro de Importação", value: "not_imported" },
    { label: "Sucesso", value: "imported" },
  ]

  const handleShowErrorDetails = (contract: ContractIntegration) => {
    setSelectedContract(contract)
    setErrorDialogVisible(true)
  }

  const statusBodyTemplate = (rowData: ContractIntegration) => {
    if (rowData.status === "imported") {
      return (
        <Badge value="Importado" severity="success" className="contract-status-badge">
          <i className="pi pi-check me-1"></i>
          Importado
        </Badge>
      )
    }
    return (
      <Badge value="Não Importado" severity="danger" className="contract-status-badge">
        <i className="pi pi-times me-1"></i>
        Não Importado
      </Badge>
    )
  }

  const logBodyTemplate = (rowData: ContractIntegration) => {
    if (rowData.status === "imported") {
      return (
        <span className="text-success small">
          <i className="pi pi-check-circle me-1"></i>
          {rowData.processingLog}
        </span>
      )
    }
    return (
      <span className="log-text" title={rowData.processingLog}>
        {rowData.processingLog}
      </span>
    )
  }

  const actionBodyTemplate = (rowData: ContractIntegration) => {
    if (rowData.status === "not_imported") {
      return (
        <Button severity="danger" size="small" onClick={() => handleShowErrorDetails(rowData)}>
          <i className="pi pi-exclamation-triangle me-1"></i>
          Log
        </Button>
      )
    }
    return (
      <Button outlined size="small" title="Ver Detalhes">
        <i className="pi pi-eye"></i>
      </Button>
    )
  }

  return (
    <div className="fx-contracts-page">
      <div className="page-header">
        <div>
          <h4 className="page-title">Processamento de Contratos</h4>
          <p className="page-subtitle">Monitoramento de envios e importações de boletas</p>
        </div>
      </div>

      <div className="kpi-cards">
        <Card className="kpi-card kpi-card-sent">
          <div className="kpi-content">
            <div className="icon-box bg-sent">
              <i className="pi pi-send"></i>
            </div>
            <div className="kpi-info">
              <h6 className="kpi-label">Contratos Enviados</h6>
              <h3 className="kpi-value">{stats?.sent || 0}</h3>
            </div>
          </div>
        </Card>

        <Card className="kpi-card kpi-card-imported">
          <div className="kpi-content">
            <div className="icon-box bg-imported">
              <i className="pi pi-check-circle"></i>
            </div>
            <div className="kpi-info">
              <h6 className="kpi-label">Importados com Sucesso</h6>
              <h3 className="kpi-value">{stats?.imported || 0}</h3>
            </div>
          </div>
        </Card>

        <Card className="kpi-card kpi-card-error">
          <div className="kpi-content">
            <div className="icon-box bg-error">
              <i className="pi pi-times-circle"></i>
            </div>
            <div className="kpi-info">
              <h6 className="kpi-label">Não Importados</h6>
              <h3 className="kpi-value">{stats?.notImported || 0}</h3>
            </div>
          </div>
        </Card>
      </div>

      <Card className="filter-card">
        <div className="filter-content">
          <div className="search-input">
            <span className="p-input-icon-left">
              <i className="pi pi-search" />
              <InputText
                placeholder="Buscar Contrato, Boleta ou CNPJ..."
                value={filters.search}
                onChange={(e) => setFilters({ ...filters, search: e.target.value })}
              />
            </span>
          </div>
          <div className="status-filter">
            <Dropdown
              value={filters.status}
              options={statusOptions}
              onChange={(e) => setFilters({ ...filters, status: e.value })}
            />
          </div>
        </div>
      </Card>

      <Card className="table-card">
        <DataTable
          value={contracts}
          loading={isLoading}
          emptyMessage="Nenhum contrato encontrado"
          rowClassName={(rowData) => (rowData.status === "not_imported" ? "error-row" : "")}
        >
          <Column
            field="contractNumber"
            header="Nº Contrato"
            body={(rowData) => <span className="contract-number">{rowData.contractNumber}</span>}
          />
          <Column
            field="boletaNumber"
            header="Nº Boleta"
            body={(rowData) => <span className="boleta-code">{rowData.boletaNumber}</span>}
          />
          <Column
            field="clientCnpj"
            header="CNPJ do Cliente"
            body={(rowData) => <span className="cnpj-text">{rowData.clientCnpj}</span>}
          />
          <Column
            field="contractDate"
            header="Data Contrato"
            body={(rowData) => new Date(rowData.contractDate).toLocaleDateString("pt-BR")}
          />
          <Column field="status" header="Status" body={statusBodyTemplate} />
          <Column field="processingLog" header="Log de Processamento" body={logBodyTemplate} />
          <Column header="Ação" body={actionBodyTemplate} className="text-end" />
        </DataTable>
      </Card>

      <Dialog
        header={
          <div className="error-dialog-header">
            <i className="pi pi-exclamation-triangle me-2"></i>
            Detalhes do Erro
          </div>
        }
        visible={errorDialogVisible}
        style={{ width: "500px" }}
        onHide={() => setErrorDialogVisible(false)}
        className="error-dialog"
      >
        {selectedContract && (
          <div className="error-details">
            <div className="error-info">
              <strong>Contrato:</strong> {selectedContract.contractNumber}
            </div>
            <div className="error-info">
              <strong>CNPJ:</strong> {selectedContract.clientCnpj}
            </div>
            <hr />
            <pre className="error-message">{selectedContract.errorDetails || selectedContract.processingLog}</pre>
          </div>
        )}
      </Dialog>
    </div>
  )
}
