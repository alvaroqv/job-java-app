"use client"

import type React from "react"

import { useState } from "react"
import { InputText } from "primereact/inputtext"
import { Button } from "primereact/button"
import { Card } from "primereact/card"
import { Message } from "primereact/message"
import { usePartyClient } from "@/hooks/usePartyClient"
import type { PartyClient } from "@/types/party-client"
import { useRouter } from "next/navigation"
import "./entity-sync.css"

export default function EntitySyncPage() {
  const [eci, setEci] = useState("")
  const [searchResult, setSearchResult] = useState<PartyClient | null>(null)
  const [error, setError] = useState<string | null>(null)
  const { search, isSearching, import: importClient, isImporting } = usePartyClient()
  const router = useRouter()

  const handleSearch = async () => {
    if (!eci.trim()) {
      return
    }

    setError(null)
    setSearchResult(null)

    try {
      const response = await search(eci.trim())

      if (response.success && response.data) {
        setSearchResult(response.data)
      } else {
        setError(response.message || "Cliente não encontrado no PartyClient com este ECI.")
      }
    } catch (err) {
      setError("Erro ao buscar cliente. Tente novamente.")
    }
  }

  const handleImport = async () => {
    if (!searchResult) return

    try {
      const response = await importClient(searchResult.eci)

      if (response.success) {
        // Show success message and redirect
        alert(response.message)
        router.push("/entities-sync")
      } else {
        alert(response.message || "Erro ao importar cliente.")
      }
    } catch (err) {
      alert("Erro ao importar cliente. Tente novamente.")
    }
  }

  const handleNewSearch = () => {
    setEci("")
    setSearchResult(null)
    setError(null)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch()
    }
  }

  return (
    <div className="entity-sync-page">
      <div className="page-header">
        <div>
          <h4 className="page-title">Importar Cliente</h4>
          <p className="page-subtitle">
            Consulta externa ao sistema{" "}
            <span className="party-logo">
              <i className="pi pi-globe"></i> PartyClient
            </span>
          </p>
        </div>
      </div>

      <div className="search-section">
        <h5 className="search-title">Digite o código ECI para buscar</h5>
        <div className="search-input-group">
          <span className="p-input-icon-left flex-1">
            <i className="pi pi-id-card"></i>
            <InputText
              value={eci}
              onChange={(e) => setEci(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ex: 90210-BR"
              className="w-full search-input"
              disabled={isSearching}
            />
          </span>
          <Button
            label="Buscar"
            icon="pi pi-search"
            onClick={handleSearch}
            loading={isSearching}
            className="search-button"
            disabled={!eci.trim()}
          />
        </div>
        <small className="search-hint">O sistema irá conectar à API do PartyClient para recuperar os dados.</small>
      </div>

      {searchResult && (
        <div className="result-container">
          <Card className="result-card">
            <div className="result-header">
              <span className="result-title">
                <i className="pi pi-check-circle"></i>
                Cliente Encontrado
              </span>
              <span className="result-badge">Origem: PartyClient API v2</span>
            </div>

            <div className="result-body">
              <div className="result-grid">
                <div className="result-field small">
                  <label>ECI</label>
                  <InputText value={searchResult.eci} readOnly className="field-readonly" />
                </div>
                <div className="result-field large">
                  <label>Nome / Razão Social</label>
                  <InputText value={searchResult.name} readOnly className="field-readonly" />
                </div>
                <div className="result-field medium">
                  <label>CNPJ / CPF</label>
                  <InputText value={searchResult.document} readOnly className="field-readonly" />
                </div>

                <div className="result-field">
                  <label>Status (PartyClient)</label>
                  <div className={`status-badge ${searchResult.status.toLowerCase()}`}>
                    <i className={`pi ${searchResult.status === "ATIVO" ? "pi-check-circle" : "pi-times-circle"}`}></i>
                    {searchResult.status}
                  </div>
                </div>
                <div className="result-field">
                  <label>Situação Cadastral</label>
                  <div className={`situation-badge ${searchResult.situation.toLowerCase()}`}>
                    <i className="pi pi-info-circle"></i>
                    {searchResult.situation}
                    {searchResult.situationDetail && ` (${searchResult.situationDetail})`}
                  </div>
                </div>
              </div>

              <Message
                severity="warn"
                className="import-warning"
                content={
                  <div>
                    <strong>Atenção:</strong> Os dados acima são apenas para visualização externa. Para utilizar este
                    cliente no JobManager, clique em "Importar Dados".
                  </div>
                }
              />
            </div>

            <div className="result-footer">
              <Button
                label="Nova Busca"
                icon="pi pi-refresh"
                outlined
                onClick={handleNewSearch}
                disabled={isImporting}
              />
              <Button
                label="Importar Dados"
                icon="pi pi-file-import"
                severity="success"
                onClick={handleImport}
                loading={isImporting}
              />
            </div>
          </Card>
        </div>
      )}

      {error && (
        <div className="error-container">
          <Message severity="error" text={error} />
        </div>
      )}
    </div>
  )
}
