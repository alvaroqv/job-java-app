"use client"

import { useState } from "react"
import { Button } from "primereact/button"
import { InputText } from "primereact/inputtext"
import { Dialog } from "primereact/dialog"
import { Message } from "primereact/message"
import { useVerifyCNPJ, useCreateSupplier, useUpdateSupplier } from "@/hooks/useSuppliers"
import type { Supplier } from "@/types/supplier"
import "./supplier-registry.css"

export default function SupplierRegistryPage() {
  const [cnpj, setCnpj] = useState("")
  const [name, setName] = useState("")
  const [verificationResult, setVerificationResult] = useState<{
    exists: boolean
    supplier?: Supplier
    message: string
  } | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)
  const [cnpjDisabled, setCnpjDisabled] = useState(false)

  const verifyCNPJMutation = useVerifyCNPJ()
  const createSupplierMutation = useCreateSupplier()
  const updateSupplierMutation = useUpdateSupplier()

  const handleVerifyCNPJ = async () => {
    if (!cnpj.trim()) {
      alert("Digite um CNPJ")
      return
    }

    try {
      const result = await verifyCNPJMutation.mutateAsync(cnpj)
      setVerificationResult(result)
      setShowForm(true)
      setCnpjDisabled(true)

      if (result.exists && result.supplier) {
        setName(result.supplier.name)
      } else {
        setName("")
      }
    } catch (error) {
      console.error("Error verifying CNPJ:", error)
    }
  }

  const handleOpenConfirmDialog = () => {
    if (!name.trim()) {
      alert("Preencha o Nome/Razão Social")
      return
    }
    setShowConfirmDialog(true)
  }

  const handleFinalizeProcess = async () => {
    try {
      if (verificationResult?.exists && verificationResult.supplier) {
        await updateSupplierMutation.mutateAsync({
          id: verificationResult.supplier.id,
          name,
        })
      } else {
        await createSupplierMutation.mutateAsync({
          cnpj,
          name,
        })
      }

      setShowConfirmDialog(false)
      alert("Sucesso! Operação realizada.")
      handleReset()
    } catch (error) {
      console.error("Error saving supplier:", error)
      alert("Erro ao salvar fornecedor")
    }
  }

  const handleReset = () => {
    setCnpj("")
    setName("")
    setVerificationResult(null)
    setShowForm(false)
    setCnpjDisabled(false)
  }

  const isLoading = verifyCNPJMutation.isPending || createSupplierMutation.isPending || updateSupplierMutation.isPending

  return (
    <div className="supplier-registry-page">
      <div className="supplier-registry-header">
        <div>
          <h4 className="page-title">Novo Fornecedor</h4>
          <p className="page-subtitle">Etapa 1: Verificação &gt; Etapa 2: Confirmação</p>
        </div>
        <Button label="Voltar" icon="pi pi-arrow-left" outlined size="small" onClick={() => window.history.back()} />
      </div>

      <div className="supplier-registry-content">
        <div className="supplier-card">
          <div className="card-header">
            <h5 className="card-title">
              <i className="pi pi-search"></i> 1. Verificação de Cadastro
            </h5>
          </div>

          <div className="card-body">
            <div className="form-group">
              <label className="form-label">CNPJ do Fornecedor</label>
              <div className="input-group">
                <InputText
                  value={cnpj}
                  onChange={(e) => setCnpj(e.target.value)}
                  placeholder="00.000.000/0000-00"
                  disabled={cnpjDisabled}
                  className="cnpj-input"
                />
                <Button
                  label="Verificar"
                  icon={verifyCNPJMutation.isPending ? "pi pi-spin pi-spinner" : "pi pi-search"}
                  onClick={handleVerifyCNPJ}
                  disabled={isLoading || cnpjDisabled}
                  loading={verifyCNPJMutation.isPending}
                />
              </div>
              <small className="form-text">Digite o CNPJ e clique em verificar para habilitar o formulário.</small>
            </div>

            {showForm && verificationResult && (
              <div className="feedback-area">
                <Message
                  severity={verificationResult.exists ? "warn" : "success"}
                  text={
                    <div className="message-content">
                      <strong>{verificationResult.message}</strong>
                      <br />
                      {verificationResult.exists
                        ? "CNPJ já existe na base. Modo de ATUALIZAÇÃO CADASTRAL."
                        : "Nenhum registro encontrado. Modo de NOVO CADASTRO."}
                    </div>
                  }
                  className="verification-message"
                />

                <div className="form-divider"></div>

                <h5 className="form-section-title">
                  <i className="pi pi-pencil"></i> 2. Dados do Fornecedor
                </h5>

                <div className="form-group">
                  <label className="form-label">Razão Social / Nome</label>
                  <InputText value={name} onChange={(e) => setName(e.target.value)} className="name-input" />
                </div>

                <div className="form-actions">
                  <Button label="Nova Consulta" outlined onClick={handleReset} disabled={isLoading} />
                  <Button
                    label="Salvar Fornecedor"
                    icon="pi pi-save"
                    severity="success"
                    onClick={handleOpenConfirmDialog}
                    disabled={isLoading}
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="tip-box">
          <strong>Dica:</strong> Use <code>00.000.000/0001-99</code> para simular um fornecedor já cadastrado.
        </div>
      </div>

      <Dialog
        header="Confirmação de Gravação"
        visible={showConfirmDialog}
        style={{ width: "450px" }}
        onHide={() => setShowConfirmDialog(false)}
        footer={
          <div>
            <Button label="Cancelar" outlined onClick={() => setShowConfirmDialog(false)} disabled={isLoading} />
            <Button
              label="Confirmar"
              severity="success"
              onClick={handleFinalizeProcess}
              loading={isLoading}
              disabled={isLoading}
            />
          </div>
        }
      >
        <p>Você está prestes a salvar os seguintes dados:</p>

        <div className="confirmation-data">
          <div className="data-row">
            <span className="data-label">Ação:</span>
            <span className={`data-value ${verificationResult?.exists ? "text-warning" : "text-success"}`}>
              {verificationResult?.exists ? "ATUALIZAÇÃO" : "NOVO CADASTRO"}
            </span>
          </div>
          <div className="data-row">
            <span className="data-label">CNPJ:</span>
            <span className="data-value">{cnpj}</span>
          </div>
          <div className="data-row">
            <span className="data-label">Nome:</span>
            <span className="data-value">{name}</span>
          </div>
        </div>

        <Message severity="warn" text="Esta ação será registrada no histórico." className="history-warning" />
      </Dialog>
    </div>
  )
}
