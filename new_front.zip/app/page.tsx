export default function HomePage() {
  return (
    <div style={{ padding: "100px 30px 30px 290px" }}>
      <h1 style={{ fontSize: "2rem", marginBottom: "1rem" }}>
        Welcome to Lexus Cockpit
      </h1>
      <p style={{ fontSize: "1.1rem", color: "var(--grey-color)" }}>
        Select an option from the sidebar to get started.
      </p>
    </div>
  );
}
