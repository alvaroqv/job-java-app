export interface MenuItem {
  id: string
  label: string
  icon: string
  url?: string
  submenu?: SubMenuItem[]
}

export interface SubMenuItem {
  id: string
  label: string
  url: string
}

export interface MenuSection {
  title: string
  items: MenuItem[]
}

export interface DashboardData {
  menuSections: MenuSection[]
}

export interface User {
  id: string
  name: string
  email: string
  avatar?: string
}
