export interface ContractIntegration {
  id: string
  contractNumber: string
  boletaNumber: string
  clientCnpj: string
  contractDate: string
  status: "imported" | "not_imported"
  processingLog: string
  errorDetails?: string
}

export interface ContractIntegrationStats {
  sent: number
  imported: number
  notImported: number
}

export interface ContractIntegrationFilters {
  search: string
  status: "all" | "imported" | "not_imported"
}
