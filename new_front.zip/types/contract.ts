export interface Contract {
  id: string
  clientName: string
  contractCode: string
  eci: string
  document: string // CNPJ or CPF
  status: "Assinado" | "Pendente" | "Novo"
  contractDate: string
  signatureDate?: string
  callbackDate?: string
  pdfUrl?: string
}

export interface ContractStats {
  newContracts: number
  pendingSignature: number
  signed: number
}

export interface ContractFilters {
  search?: string
  document?: string
  status?: string
  startDate?: string
  endDate?: string
}

export interface ContractSearchResponse {
  contracts: Contract[]
  total: number
  filtered: number
}
