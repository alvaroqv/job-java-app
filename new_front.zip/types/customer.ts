export interface Customer {
  id: string;
  name: string;
  email: string;
  eci: string;
  cnpjCpf: string;
  createdAt: string;
  updatedAt: string;
  status: "Ativo" | "Inativo";
  situation: "Regular" | "Bloqueado" | "Em Análise";
  avatar?: string;
}

export interface CustomerKPIs {
  newRegistrations: {
    count: number;
    percentageChange: number;
  };
  updates: {
    count: number;
  };
  deactivations: {
    count: number;
  };
  reactivations: {
    count: number;
  };
}

export interface CustomerFilters {
  search: string;
  status: "all" | "Ativo" | "Inativo";
}

export interface CustomerListResponse {
  customers: Customer[];
  kpis: CustomerKPIs;
  totalRecords: number;
}
