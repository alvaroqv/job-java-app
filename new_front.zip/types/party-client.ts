export interface PartyClient {
  eci: string
  name: string
  document: string // CNPJ/CPF
  status: "ATIVO" | "INATIVO"
  situation: "REGULAR" | "IRREGULAR" | "BLOQUEADO"
  situationDetail?: string
}

export interface PartyClientSearchResponse {
  success: boolean
  data?: PartyClient
  message?: string
}

export interface ImportResponse {
  success: boolean
  message: string
  clientId?: string
}
