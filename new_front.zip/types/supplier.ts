export interface Supplier {
  id: string
  cnpj: string
  name: string
  createdAt: string
  updatedAt: string
  status: "Ativo" | "Inativo"
}

export interface SupplierVerificationResult {
  exists: boolean
  supplier?: Supplier
  message: string
}

export interface SupplierFormData {
  cnpj: string
  name: string
}
