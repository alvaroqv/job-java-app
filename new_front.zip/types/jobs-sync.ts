export interface JobExecution {
  id: string;
  status: "success" | "error" | "running";
  jobName: string;
  area: string;
  startTime: string;
}

export interface Job {
  id: string;
  name: string;
  type: "SQL" | "Python";
  cron: string;
}

export interface JobParameter {
  id: string;
  name: string;
  type: "Data" | "String" | "Number";
  defaultValue: string;
}

export interface SqlColumn {
  sqlColumn: string;
  alias: string;
  format: string;
}

export interface Report {
  id: string;
  jobName: string;
  generationDate: string;
  size: string;
}

export interface DatabaseConnection {
  id: string;
  name: string;
  driver: "PostgreSQL" | "Oracle DB" | "SQL Server" | "MySQL";
  host: string;
  database: string;
  port?: string;
  username?: string;
}

export interface EntitiesSyncStats {
  running: number;
  success24h: number;
  errors24h: number;
}
