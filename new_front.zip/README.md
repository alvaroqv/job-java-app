# Lexus Cockpit - Control Center

A React dashboard application built with Next.js, PrimeReact, and React Query.

## Features

- 🎨 Modern UI with PrimeReact components and PrimeIcons
- 🌗 Dark/Light theme toggle
- 📱 Responsive design
- 🔄 React Query for data fetching and caching
- 🏗️ Clean architecture with separation of concerns
- 📦 Mock data ready for API integration

## Project Structure

```
/app                 # Next.js app directory
  /api              # API routes (ready for backend)
  layout.tsx        # Root layout with providers
  page.tsx          # Home page
  globals.css       # Global styles
  providers.tsx     # React Query provider

/components         # React components
  /layout          # Layout components
    AppLayout.tsx  # Main layout wrapper
    Navbar.tsx     # Top navigation bar
    Sidebar.tsx    # Side navigation menu

/services          # Service layer
  /api             # API service modules
    apiClient.ts   # Axios instance with interceptors
    dashboardService.ts  # Dashboard API calls

/hooks             # Custom React hooks
  useDashboard.ts  # React Query hooks for dashboard

/lib               # Utilities and helpers
  mockData.ts      # Mock data for development

/types             # TypeScript type definitions
  dashboard.ts     # Dashboard related types
```

## Getting Started

1. Install dependencies:
```bash
npm install
```

2. Run the development server:
```bash
npm run dev
```

3. Open [http://localhost:3000](http://localhost:3000)

## API Integration

The project uses mock data by default. To integrate with your backend:

1. Set the API URL in your environment variables:
```env
NEXT_PUBLIC_API_URL=https://your-api-url.com
```

2. Update the service methods in `/services/api/dashboardService.ts`:
   - Uncomment the actual API calls
   - Remove the mock data returns

3. The `apiClient` automatically handles:
   - Authentication tokens
   - Request/response interceptors
   - Error handling

## Architecture Principles

- **Separation of Concerns**: Components, services, and data are separated
- **Service Layer**: Axios and React Query abstract API communication
- **Type Safety**: TypeScript types for all data structures
- **Reusability**: Modular components and services
- **Maintainability**: Clear folder structure and naming conventions

## Technologies

- Next.js 16
- React 19
- PrimeReact 10
- PrimeIcons 7
- React Query (TanStack Query) 5
- Axios
- TypeScript
