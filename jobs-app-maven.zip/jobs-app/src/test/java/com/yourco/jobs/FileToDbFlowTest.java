package com.yourco.jobs;

import com.yourco.jobs.pipeline.*;
import com.yourco.jobs.writers.DbWriter;
import com.yourco.jobs.readers.CsvFileReader;
import com.yourco.jobs.queries.QueryRegistry;
import com.yourco.jobs.config.MultiDsConfig; import com.yourco.jobs.config.MultiDsRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.*;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.jdbc.core.JdbcTemplate;

import java.nio.file.Path; import java.util.Map;

public class FileToDbFlowTest {
  private final ApplicationContextRunner ctx = new ApplicationContextRunner()
    .withUserConfiguration(App.class, MultiDsConfig.class);

  @Test
  void csv_to_db_upsert_h2() {
    ctx.run(c -> {
      MultiDsRegistry ds = c.getBean(MultiDsRegistry.class);
      JdbcTemplate jt = ds.jdbc("operational");
      jt.execute("CREATE TABLE orders(id INT PRIMARY KEY, customer_id INT, total_amount DECIMAL(10,2), updated_at TIMESTAMP)");

      ItemReader<Map<String,String>> reader = new CsvFileReader(Path.of("src/test/resources/data/orders.csv"));
      QueryRegistry qreg = c.getBean(QueryRegistry.class);
      ItemWriter<Map<String,Object>> writer = new DbWriter(jt, qreg, "FILE_TO_DB", "upsertOrders", "h2", 1000);
      PipelineExecutor exec = new PipelineExecutor(new SimpleMeterRegistry());
      ErrorSink sink = new FileErrorSink(Path.of("./build/test-dlq"));

      Assertions.assertDoesNotThrow(() -> exec.execute("FILE_TO_DB", 1000, reader, (in) -> Map.copyOf(in), writer, sink));

      Integer count = jt.queryForObject("SELECT COUNT(*) FROM orders", Integer.class);
      Assertions.assertEquals(2, count);
    });
  }
}
