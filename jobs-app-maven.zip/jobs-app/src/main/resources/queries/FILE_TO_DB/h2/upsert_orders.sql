MERGE INTO orders (id, customer_id, total_amount, updated_at)
KEY(id)
VALUES(:id, :customer_id, :total_amount, :updated_at);
