SELECT id, customer_id, total_amount, updated_at
FROM orders
WHERE updated_at BETWEEN :fromDate AND :toDate
ORDER BY updated_at, id
LIMIT :limit OFFSET :offset;
