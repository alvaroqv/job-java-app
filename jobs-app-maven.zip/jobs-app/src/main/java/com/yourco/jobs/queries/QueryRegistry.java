package com.yourco.jobs.queries;

import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.Yaml;
import java.io.*; import java.nio.file.*; import java.util.*;

@Component
public class QueryRegistry {
  private static final Logger log = LoggerFactory.getLogger(QueryRegistry.class);
  private final Path basePath; private final String defaultDialect; private final Map<String,Object> catalog;
  public QueryRegistry(Environment env) throws IOException {
    this.basePath = Path.of(env.getProperty("app.queries.base-path", "src/main/resources/queries"));
    this.defaultDialect = env.getProperty("app.queries.default-dialect", "postgres");
    Path cat = basePath.resolve("catalog.yml");
    this.catalog = Files.exists(cat)? new Yaml().load(Files.newBufferedReader(cat)) : Map.of();
  }
  public LoadedQuery load(String jobName, String queryRef, String dialect) throws IOException {
    String rel = resolvePath(jobName, queryRef, dialect);
    Path sqlPath = basePath.resolve(rel);
    String sql = Files.readString(sqlPath);
    String checksum = Integer.toHexString(sql.hashCode());
    log.info("Loaded SQL job={} query={} dialect={} path={} checksum={}", jobName, queryRef, dialect, sqlPath, checksum);
    return new LoadedQuery(jobName, queryRef, dialect, sql, checksum);
  }
  private String resolvePath(String job, String ref, String dialect) {
    try {
      Map<String,Object> jobs = (Map<String,Object>) catalog.get("jobs");
      Map<String,Object> jobSec = (Map<String,Object>) jobs.get(job);
      Map<String,Object> queries = (Map<String,Object>) jobSec.get("queries");
      Map<String,Object> q = (Map<String,Object>) queries.get(ref);
      Map<String,String> paths = (Map<String,String>) q.get("paths");
      return paths.getOrDefault(dialect, paths.getOrDefault(defaultDialect, paths.values().iterator().next()));
    } catch (Exception e) {
      return job + "/" + (dialect==null? defaultDialect : dialect) + "/" + ref + ".sql";
    }
  }
  public record LoadedQuery(String job, String name, String dialect, String sql, String checksum) {}
}
