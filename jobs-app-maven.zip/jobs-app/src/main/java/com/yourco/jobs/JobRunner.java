package com.yourco.jobs;

import com.yourco.jobs.pipeline.PipelineExecutor;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class JobRunner implements ApplicationRunner {
  private static final Logger log = LoggerFactory.getLogger(JobRunner.class);
  private final PipelineFactory factory;
  public JobRunner(PipelineFactory factory) { this.factory = factory; }
  @Override public void run(ApplicationArguments args) throws Exception {
    JobParams p = JobParams.from(args);
    log.info("Starting job name={} queryRef={} ds={} format={}", p.jobName(), p.queryRef(), p.ds(), p.format());
    factory.buildAndRun(p);
  }
}
