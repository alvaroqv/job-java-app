package com.yourco.jobs.writers;

import com.opencsv.CSVWriter; import com.yourco.jobs.pipeline.ItemWriter;
import java.io.*; import java.nio.charset.StandardCharsets; import java.nio.file.*; import java.util.*;

public class CsvWriter implements ItemWriter<Map<String,Object>> {
  private final Path out; private final boolean header; private CSVWriter w; private List<String> cols;
  public CsvWriter(Path out, boolean header) { this.out = out; this.header = header; }
  public void open() throws Exception { Files.createDirectories(out.getParent()); w = new CSVWriter(new BufferedWriter(new OutputStreamWriter(Files.newOutputStream(out), StandardCharsets.UTF_8))); }
  public void write(List<Map<String,Object>> items) throws Exception {
    if (items.isEmpty()) return; if (cols==null) { cols = new ArrayList<>(items.get(0).keySet()); if (header) w.writeNext(cols.toArray(new String[0])); }
    for (var m: items) { String[] row = cols.stream().map(c -> Objects.toString(m.get(c), "")).toArray(String[]::new); w.writeNext(row, false); }
  }
  public void close() throws Exception { if (w!=null) w.close(); }
}
