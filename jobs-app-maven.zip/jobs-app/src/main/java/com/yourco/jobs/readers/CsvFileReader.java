package com.yourco.jobs.readers;

import com.opencsv.CSVReader; import com.yourco.jobs.pipeline.ItemReader;
import java.io.*; import java.nio.charset.StandardCharsets; import java.nio.file.*; import java.util.*;

public class CsvFileReader implements ItemReader<Map<String,String>> {
  private final Path path; private CSVReader reader; private String[] headers;
  public CsvFileReader(Path path) { this.path = path; }
  public void open() throws Exception { reader = new CSVReader(new BufferedReader(new InputStreamReader(Files.newInputStream(path), StandardCharsets.UTF_8))); headers = reader.readNext(); }
  public Map<String,String> read() throws Exception {
    String[] row = reader.readNext(); if (row==null) return null; Map<String,String> m = new LinkedHashMap<>();
    for (int i=0;i<headers.length && i<row.length;i++) m.put(headers[i], row[i]); return m; }
  public void close() throws Exception { if (reader!=null) reader.close(); }
}
