package com.yourco.jobs;

import com.yourco.jobs.pipeline.*;
import com.yourco.jobs.queries.JdbcQueryExecutor;
import com.yourco.jobs.readers.*;
import com.yourco.jobs.writers.*;
import com.yourco.jobs.config.MultiDsRegistry;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Value;
import java.nio.file.Path;
import java.time.ZoneId;
import java.util.*;

@Component
public class PipelineFactory {
  private final PipelineExecutor exec;
  private final JdbcQueryExecutor jdbcExec;
  private final MultiDsRegistry dsReg;
  @Value("${app.job.defaults.dlq.dir:/data/dlq}") String dlqDir;
  @Value("${app.job.defaults.excel.timezone:America/Sao_Paulo}") String excelTz;

  public PipelineFactory(PipelineExecutor exec, JdbcQueryExecutor jdbcExec, MultiDsRegistry dsReg) {
    this.exec = exec; this.jdbcExec = jdbcExec; this.dsReg = dsReg;
  }

  public void buildAndRun(JobParams p) throws Exception {
    ErrorSink sink = new FileErrorSink(Path.of(dlqDir));
    switch (p.jobName()) {
      case "DB_TO_FILE" -> runDbToFile(p, sink);
      case "FILE_TO_DB" -> runFileToDb(p, sink);
      case "API_TO_DB" -> throw new UnsupportedOperationException("API_TO_DB stub");
      default -> throw new IllegalArgumentException("Unknown job: " + p.jobName());
    }
  }

  private void runDbToFile(JobParams p, ErrorSink sink) throws Exception {
    Map<String,Object> params = new HashMap<>();
    params.put("fromDate", p.fromDate()); params.put("toDate", p.toDate());
    params.put("limit", p.chunk()); params.put("offset", 0);
    var reader = new JdbcPagingReader(jdbcExec, p.ds(), p.dialect(), p.jobName(), p.queryRef(), params, p.chunk());
    ItemProcessor<Map<String,Object>,Map<String,Object>> proc = i -> i; // no-op
    var out = Path.of(p.outDir(), "export_" + p.queryRef() + (p.format().equalsIgnoreCase("XLSX")? ".xlsx": ".csv"));
    ItemWriter<Map<String,Object>> writer = p.format().equalsIgnoreCase("XLSX")
      ? new ExcelWriter(out, ZoneId.of(excelTz))
      : new CsvWriter(out, true);
    exec.execute(p.jobName(), p.chunk(), reader, proc, writer, sink);
  }

  private void runFileToDb(JobParams p, ErrorSink sink) throws Exception {
    var reader = new CsvFileReader(Path.of(p.in()));
    var jt = dsReg.jdbc(p.ds());
    var writer = new DbWriter(jt, p.jobName(), p.queryRef(), p.dialect(), 2000);
    exec.execute(p.jobName(), p.chunk(), reader, null, writer, sink);
  }
}
