package com.yourco.jobs.pipeline;

import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import java.nio.file.*; import java.io.*; import java.util.Map;

public class FileErrorSink implements ErrorSink {
  private static final Logger log = LoggerFactory.getLogger(FileErrorSink.class);
  private final Path dlqDir;
  public FileErrorSink(Path dlqDir) { this.dlqDir = dlqDir; }
  private void write(String phase, Exception ex, Object obj) {
    try {
      Files.createDirectories(dlqDir);
      String line = Map.of("phase", phase, "exception", ex.getClass().getName(),
        "message", ex.getMessage(), "item", String.valueOf(obj)).toString();
      Files.writeString(dlqDir.resolve("dlq.jsonl"), line + System.lineSeparator(),
        StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    } catch (IOException io) { log.error("DLQ write failed", io); }
  }
  public void onReadError(Exception ex, Object ctx) { write("read", ex, ctx); }
  public void onProcessError(Exception ex, Object item) { write("process", ex, item); }
}
