package com.yourco.jobs.pipeline;
public interface ItemProcessor<I,O> { O process(I item) throws Exception; }
