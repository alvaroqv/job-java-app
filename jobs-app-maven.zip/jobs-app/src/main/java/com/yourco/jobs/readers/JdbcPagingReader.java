package com.yourco.jobs.readers;

import com.yourco.jobs.pipeline.ItemReader;
import com.yourco.jobs.queries.JdbcQueryExecutor;
import java.util.*;

public class JdbcPagingReader implements ItemReader<Map<String,Object>> {
  private final JdbcQueryExecutor exec; private final String ds, dialect, job, ref; private final Map<String,Object> params; private final int pageSize; private Iterator<Map<String,Object>> it;
  public JdbcPagingReader(JdbcQueryExecutor exec, String ds, String dialect, String jobName, String queryRef, Map<String,Object> params, int pageSize) {
    this.exec=exec; this.ds=ds; this.dialect=dialect; this.job=jobName; this.ref=queryRef; this.params=params; this.pageSize=pageSize; }
  public void open() throws Exception { it = exec.iterate(ds, dialect, job, ref, params, pageSize); }
  public Map<String,Object> read() { return it.hasNext()? it.next(): null; }
  public void close() {}
}
