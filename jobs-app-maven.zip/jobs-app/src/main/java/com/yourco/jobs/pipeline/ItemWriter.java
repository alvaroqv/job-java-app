package com.yourco.jobs.pipeline;
import java.util.List;
public interface ItemWriter<O> extends AutoCloseable {
  void open() throws Exception;
  void write(List<O> items) throws Exception;
  @Override void close() throws Exception;
}
