package com.yourco.jobs.pipeline;

import io.micrometer.core.instrument.*;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import java.util.*; import java.util.concurrent.TimeUnit;

@Component
public class PipelineExecutor {
  private static final Logger log = LoggerFactory.getLogger(PipelineExecutor.class);
  private final MeterRegistry metrics;
  public PipelineExecutor(MeterRegistry reg) { this.metrics = reg; }

  public <I,O> void execute(String jobName, int chunk,
                            ItemReader<I> reader,
                            ItemProcessor<I,O> proc,
                            ItemWriter<O> writer,
                            ErrorSink errorSink) throws Exception {
    long start = System.currentTimeMillis();
    Counter readC = metrics.counter("job_items_read_total", "job", jobName);
    Counter writeC = metrics.counter("job_items_written_total", "job", jobName);
    Counter errC = metrics.counter("job_errors_total", "job", jobName);

    List<O> buf = new ArrayList<>(chunk);
    reader.open(); writer.open();
    try {
      while (true) {
        I in;
        try { in = reader.read(); } catch (Exception ex) { errC.increment(); errorSink.onReadError(ex, null); continue; }
        if (in == null) break; readC.increment();
        try {
          O out = proc==null? (O) in : proc.process(in); buf.add(out);
          if (buf.size() >= chunk) { writer.write(buf); writeC.increment(buf.size()); buf.clear(); }
        } catch (Exception ex) { errC.increment(); errorSink.onProcessError(ex, in); }
      }
      if (!buf.isEmpty()) { writer.write(buf); writeC.increment(buf.size()); }
    } finally {
      reader.close(); writer.close();
      long elapsed = System.currentTimeMillis() - start;
      metrics.timer("job_duration_seconds", "job", jobName).record(elapsed, TimeUnit.MILLISECONDS);
      log.info("job={} status=FINISHED elapsedMs={}", jobName, elapsed);
    }
  }
}
