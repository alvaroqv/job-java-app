package com.yourco.jobs.queries;

import com.yourco.jobs.config.MultiDsRegistry;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import java.io.IOException; import java.util.*;

@Component
public class JdbcQueryExecutor {
  private static final Logger log = LoggerFactory.getLogger(JdbcQueryExecutor.class);
  private final MultiDsRegistry dsReg; private final QueryRegistry qr;
  public JdbcQueryExecutor(MultiDsRegistry dsReg, QueryRegistry qr) { this.dsReg = dsReg; this.qr = qr; }

  public Iterator<Map<String,Object>> iterate(String ds, String dialect, String jobName, String queryRef, Map<String,?> params, int pageSize) throws IOException {
    var jt = new NamedParameterJdbcTemplate(dsReg.ds(ds));
    var loaded = qr.load(jobName, queryRef, dialect);
    final String sql = loaded.sql();
    return new Iterator<>() {
      int offset = (int) params.getOrDefault("offset", 0);
      Iterator<Map<String,Object>> current = Collections.emptyIterator();
      @Override public boolean hasNext() {
        if (current.hasNext()) return true;
        Map<String,Object> p = new HashMap<>(params); p.put("limit", pageSize); p.put("offset", offset);
        var list = jt.query(sql, p, (rs, rn) -> {
          var md = rs.getMetaData(); Map<String,Object> row = new LinkedHashMap<>();
          for (int i=1;i<=md.getColumnCount();i++) row.put(md.getColumnLabel(i), rs.getObject(i));
          return row; });
        if (list.isEmpty()) return false; current = list.iterator(); offset += pageSize; return true;
      }
      @Override public Map<String,Object> next() { return current.next(); }
    };
  }
}
