package com.yourco.jobs.pipeline;
public interface ErrorSink {
  void onReadError(Exception ex, Object ctx);
  void onProcessError(Exception ex, Object item);
}
