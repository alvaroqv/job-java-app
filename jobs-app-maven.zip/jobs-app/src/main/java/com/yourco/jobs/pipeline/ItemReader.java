package com.yourco.jobs.pipeline;
public interface ItemReader<T> extends AutoCloseable {
  void open() throws Exception;
  T read() throws Exception;
  @Override void close() throws Exception;
}
