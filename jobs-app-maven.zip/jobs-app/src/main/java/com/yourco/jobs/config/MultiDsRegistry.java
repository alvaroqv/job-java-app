package com.yourco.jobs.config;

import org.springframework.jdbc.core.JdbcTemplate;
import javax.sql.DataSource;
import java.util.Map;

public class MultiDsRegistry {
  private final Map<String, DataSource> dataSources;
  private final Map<String, JdbcTemplate> jdbcTemplates;
  private final String def;
  public MultiDsRegistry(Map<String, DataSource> d, Map<String, JdbcTemplate> j, String def) { this.dataSources=d; this.jdbcTemplates=j; this.def=def; }
  public JdbcTemplate jdbc(String name) { return jdbcTemplates.getOrDefault(name, jdbcTemplates.get(def)); }
  public DataSource ds(String name) { return dataSources.getOrDefault(name, dataSources.get(def)); }
}
