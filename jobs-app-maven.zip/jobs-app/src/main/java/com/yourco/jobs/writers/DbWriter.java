package com.yourco.jobs.writers;

import com.yourco.jobs.pipeline.ItemWriter;
import com.yourco.jobs.queries.QueryRegistry;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.*;
import java.util.*;

public class DbWriter implements ItemWriter<Map<String,Object>> {
  private final NamedParameterJdbcTemplate jt; private final QueryRegistry qreg; private final String job, ref, dialect; private final int batchSize;
  public DbWriter(JdbcTemplate jt, String jobName, String queryRef, String dialect, int batchSize) { this.jt = new NamedParameterJdbcTemplate(jt); this.qreg = null; this.job=jobName; this.ref=queryRef; this.dialect=dialect; this.batchSize=batchSize; }
  public DbWriter(NamedParameterJdbcTemplate jt, QueryRegistry qreg, String jobName, String queryRef, String dialect, int batchSize) { this.jt = jt; this.qreg=qreg; this.job=jobName; this.ref=queryRef; this.dialect=dialect; this.batchSize=batchSize; }
  public void open() {}
  public void write(List<Map<String,Object>> items) throws Exception {
    if (items.isEmpty()) return; String sql;
    if (qreg!=null) sql = qreg.load(job, ref, dialect).sql(); else sql = "INSERT INTO orders(id,customer_id,total_amount,updated_at) VALUES(:id,:customer_id,:total_amount,:updated_at)";
    for (int i=0;i<items.size(); i+=batchSize) {
      var slice = items.subList(i, Math.min(i+batchSize, items.size()));
      MapSqlParameterSource[] params = slice.stream().map(MapSqlParameterSource::new).toArray(MapSqlParameterSource[]::new);
      jt.batchUpdate(sql, params);
    }
  }
  public void close() {}
}
