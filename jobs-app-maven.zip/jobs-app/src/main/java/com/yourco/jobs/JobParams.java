package com.yourco.jobs;

import org.springframework.boot.ApplicationArguments;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.function.Function;

public record JobParams(String jobName, String queryRef, String dialect, String ds,
                        String in, String outDir, String table, String format,
                        LocalDateTime fromDate, LocalDateTime toDate, int chunk) {
  public static JobParams from(ApplicationArguments args) {
    Function<String,String> get = k -> Optional.ofNullable(args.getOptionValues(k))
      .filter(l -> !l.isEmpty()).map(l -> l.get(0)).orElse(null);
    return new JobParams(
      get.apply("job.name"),
      get.apply("job.queryRef"),
      Optional.ofNullable(get.apply("dialect")).orElse("postgres"),
      Optional.ofNullable(get.apply("ds")).orElse("reporting"),
      get.apply("in"),
      Optional.ofNullable(get.apply("outDir")).orElse("/data/out"),
      get.apply("table"),
      Optional.ofNullable(get.apply("format")).orElse("CSV"),
      parseDT(get.apply("fromDate")),
      parseDT(get.apply("toDate")),
      Optional.ofNullable(get.apply("chunk")).map(Integer::parseInt).orElse(5000)
    );
  }
  private static LocalDateTime parseDT(String s) { return s==null? null : LocalDateTime.parse(s); }
}
