package com.yourco.jobs.writers;

import com.yourco.jobs.pipeline.ItemWriter;
import org.apache.poi.ss.usermodel.*; import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import java.io.*; import java.nio.file.*; import java.time.*; import java.util.*;

public class ExcelWriter implements ItemWriter<Map<String,Object>> {
  private final Path out; private final ZoneId zoneId; private SXSSFWorkbook wb; private Sheet sheet; private List<String> cols; private CellStyle dateStyle; private int rowIdx=0;
  public ExcelWriter(Path out, ZoneId zoneId) { this.out = out; this.zoneId = zoneId; }
  public void open() throws Exception { Files.createDirectories(out.getParent()); wb = new SXSSFWorkbook(100); sheet = wb.createSheet("data"); DataFormat df = wb.createDataFormat(); dateStyle = wb.createCellStyle(); dateStyle.setDataFormat(df.getFormat("yyyy-mm-dd hh:mm:ss")); }
  public void write(List<Map<String,Object>> items) throws Exception {
    if (items.isEmpty()) return; if (cols==null) { cols = new ArrayList<>(items.get(0).keySet()); var hdr = sheet.createRow(rowIdx++); for (int i=0;i<cols.size();i++) hdr.createCell(i).setCellValue(cols.get(i)); }
    for (var m: items) { var r = sheet.createRow(rowIdx++); int i=0; for (var c: cols) { var cell = r.createCell(i++); Object v = m.get(c);
        if (v instanceof java.time.LocalDateTime ldt) { cell.setCellStyle(dateStyle); cell.setCellValue(java.util.Date.from(ldt.atZone(zoneId).toInstant())); }
        else if (v instanceof Number n) cell.setCellValue(n.doubleValue()); else cell.setCellValue(Objects.toString(v, "")); } }
  }
  public void close() throws Exception { try (OutputStream os = Files.newOutputStream(out)) { wb.write(os); } wb.dispose(); wb.close(); }
}
