package com.yourco.jobs.config;

import com.zaxxer.hikari.*;
import org.springframework.context.annotation.*;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import javax.sql.DataSource;
import java.util.*; import java.util.stream.Collectors;

@Configuration
public class MultiDsConfig {
  @Bean
  public MultiDsRegistry multiDsRegistry(Environment env) {
    String base = "app.ds.list.";
    Set<String> names = env.getProperty(base + "names", String.class, "reporting").lines().collect(Collectors.toSet());
    Map<String, DataSource> dsMap = new HashMap<>();
    Map<String, JdbcTemplate> jtMap = new HashMap<>();
    names.forEach(name -> {
      String p = base + name + ".";
      HikariConfig cfg = new HikariConfig();
      cfg.setJdbcUrl(env.getProperty(p + "url"));
      cfg.setUsername(env.getProperty(p + "username"));
      cfg.setPassword(env.getProperty(p + "password"));
      cfg.setDriverClassName(env.getProperty(p + "driverClassName"));
      cfg.setMaximumPoolSize(8);
      DataSource ds = new HikariDataSource(cfg);
      dsMap.put(name, ds);
      JdbcTemplate jt = new JdbcTemplate(ds);
      jt.setFetchSize(env.getProperty("app.job.defaults.fetchSize", Integer.class, 10_000));
      jtMap.put(name, jt);
    });
    String def = env.getProperty("app.ds.default", "reporting");
    return new MultiDsRegistry(dsMap, jtMap, def);
  }
}
