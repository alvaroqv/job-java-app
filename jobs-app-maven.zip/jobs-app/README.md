# jobs-app (batch without Spring Batch) — Maven

## Build
```bash
mvn clean package -DskipTests
```

## Run (DB→FILE CSV)
```bash
java -jar target/jobs-app-1.0.0.jar   --job.name=DB_TO_FILE   --job.queryRef=ordersByDate   --dialect=postgres   --ds=reporting   --fromDate=2025-08-01T00:00:00   --toDate=2025-08-24T23:59:59   --format=CSV   --outDir=./out   --chunk=5000
```
